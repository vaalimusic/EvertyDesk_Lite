//! Host service — two independent subsystems:
//!
//! 1. **Registration loop** (`run_host_loop`): connects to the ID server,
//!    sends `RegisterPeer`, keeps the registration alive with heartbeats, and
//!    forwards incoming `RequestRelay` messages to the UI.
//!
//! 2. **Relay session** (`handle_relay_session`): spawned for each accepted
//!    incoming connection.  Connects to the relay server, runs the RustDesk
//!    auth handshake (Hash → LoginRequest → LoginResponse), then enters a
//!    capture / encode / stream loop while receiving mouse & keyboard events
//!    from the remote client.

use std::{
    io::Write,
    net::{TcpStream, UdpSocket},
    sync::{
        atomic::{AtomicBool, Ordering},
        mpsc::{self, Receiver, Sender},
        Arc,
    },
    thread,
    time::{Duration, Instant},
};

use sha2::{Digest, Sha256};

use crate::{
    crypto::{self, StreamCipher},
    rustdesk_proto::{
        decode_message, decode_peer_message, encode_message, encode_peer_message, login_response,
        peer_message, rendezvous_message, video_frame, DisplayInfo, EncodedVideoFrame,
        EncodedVideoFrames, Hash, IdPk, LoginResponse, PeerInfo, PeerMessage, RegisterPeer,
        RegisterPk, RelayResponse, RendezvousMessage, RequestRelay, SignedId, VideoFrame,
    },
    settings::AppConfig,
    transport::{connect_tcp, encode_frame_len, read_framed, send_framed},
};
use prost::Message as _;

const RENDEZVOUS_PORT: u16 = 21116;
const RELAY_PORT: u16 = 21117;
const HEARTBEAT_INTERVAL: Duration = Duration::from_secs(28);
const READ_TIMEOUT_SHORT: Duration = Duration::from_millis(300);
const READ_TIMEOUT_AUTH: Duration = Duration::from_secs(10);
const TARGET_FPS: u64 = 20; // start conservative; 50 ms / frame
const FRAME_BUDGET: Duration = Duration::from_millis(1000 / TARGET_FPS);

// ── Public types ──────────────────────────────────────────────────────────────

/// Observable state of the host service.
#[derive(Debug, Clone, PartialEq)]
pub enum HostState {
    Idle,
    Connecting,
    /// Registered and waiting for incoming connections.
    Ready,
    /// Relay session in progress.
    Accepting(String),
    Error(String),
}

impl HostState {
    pub fn is_online(&self) -> bool {
        matches!(self, HostState::Ready | HostState::Accepting(_))
    }

    pub fn label(&self) -> &str {
        match self {
            HostState::Idle => "Остановлен",
            HostState::Connecting => "Подключение...",
            HostState::Ready => "Готов к подключению",
            HostState::Accepting(_) => "Сессия активна",
            HostState::Error(_) => "Ошибка",
        }
    }

    pub fn color(&self) -> EguiColor {
        match self {
            HostState::Ready => (0x43, 0xA8, 0x47),
            HostState::Connecting => (0xF5, 0xA6, 0x23),
            HostState::Accepting(_) => (0x29, 0x9D, 0xD8),
            HostState::Error(_) => (0xE0, 0x50, 0x50),
            HostState::Idle => (0x88, 0x88, 0x88),
        }
    }
}

/// RGB triple used to avoid importing egui from this module.
pub type EguiColor = (u8, u8, u8);

/// Events sent from the host background thread to the UI.
#[derive(Debug, Clone)]
pub enum HostEvent {
    StateChanged(HostState),
    Registered {
        #[allow(dead_code)]
        request_pk: bool,
    },
    IncomingRequest {
        peer_id: String,
        #[allow(dead_code)]
        relay_server: String,
        #[allow(dead_code)]
        uuid: String,
    },
    SessionStarted {
        peer_id: String,
    },
    SessionEnded {
        peer_id: String,
        reason: String,
    },
    Log(String),
}

/// Commands sent from the UI to the host thread.
#[derive(Debug)]
pub enum HostCommand {
    Stop,
    Reconfigure(AppConfig),
}

// ── Service handle ────────────────────────────────────────────────────────────

pub struct HostService {
    pub event_rx: Receiver<HostEvent>,
    command_tx: Sender<HostCommand>,
}

impl HostService {
    pub fn start(config: AppConfig) -> Self {
        let (event_tx, event_rx) = mpsc::channel::<HostEvent>();
        let (command_tx, command_rx) = mpsc::channel::<HostCommand>();
        thread::spawn(move || run_host_loop(config, event_tx, command_rx));
        Self {
            event_rx,
            command_tx,
        }
    }

    pub fn stop(&self) {
        let _ = self.command_tx.send(HostCommand::Stop);
    }

    pub fn reconfigure(&self, config: AppConfig) {
        let _ = self.command_tx.send(HostCommand::Reconfigure(config));
    }

    pub fn try_recv(&self) -> Option<HostEvent> {
        self.event_rx.try_recv().ok()
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Windows Firewall helpers
// ═══════════════════════════════════════════════════════════════════════════════

/// On Windows, registers an inbound UDP firewall exception for the current
/// executable so that hbbs can send `RegisterPeerResponse` / `RequestRelay`
/// packets back to us.
///
/// Uses `netsh advfirewall` (no external tools required).  If the rule already
/// exists the function returns immediately.  If `netsh` fails due to missing
/// admin rights, it re-tries via `powershell Start-Process -Verb RunAs`
/// (triggers a one-time UAC elevation dialog).
///
/// On non-Windows platforms this is a no-op.
fn setup_udp_firewall(events: &Sender<HostEvent>) {
    #[cfg(target_os = "windows")]
    {
        use std::process::Command;

        const RULE: &str = "EvertyDesk-Lite-UDP";

        let exe = match std::env::current_exe() {
            Ok(p) => p.to_string_lossy().into_owned(),
            Err(_) => return,
        };

        // ── Check whether the rule already exists ─────────────────────────
        let already = Command::new("netsh")
            .args([
                "advfirewall",
                "firewall",
                "show",
                "rule",
                &format!("name={RULE}"),
            ])
            .output()
            .map(|o| {
                // Rule name appears in output if it exists (byte-safe, ASCII)
                o.stdout.windows(RULE.len()).any(|w| w == RULE.as_bytes())
            })
            .unwrap_or(false);

        if already {
            host_log(events, "Firewall UDP rule already present ✓".to_owned());
            return;
        }

        host_log(
            events,
            "Добавление правила Windows Firewall для входящего UDP…".to_owned(),
        );

        let netsh_args = [
            "advfirewall",
            "firewall",
            "add",
            "rule",
            &format!("name={RULE}"),
            "dir=in",
            "action=allow",
            "protocol=UDP",
            &format!("program={exe}"),
            "enable=yes",
        ];

        // ── First attempt: run directly (works when already admin) ────────
        let direct_ok = Command::new("netsh")
            .args(&netsh_args)
            .output()
            .map(|o| o.status.success())
            .unwrap_or(false);

        if direct_ok {
            host_log(events, "Firewall UDP rule added ✓".to_owned());
            return;
        }

        // ── Second attempt: request elevation via PowerShell UAC ──────────
        // Builds: powershell -NoProfile -Command
        //         Start-Process netsh -Verb RunAs -Wait -ArgumentList '...'
        let joined_args = netsh_args.join(" ");
        let ps_cmd = format!("Start-Process netsh -Verb RunAs -Wait -ArgumentList '{joined_args}'");

        host_log(
            events,
            "Запрос прав администратора для правила файрвола (UAC)…".to_owned(),
        );

        let elevated_ok = Command::new("powershell")
            .args(["-NoProfile", "-NonInteractive", "-Command", &ps_cmd])
            .output()
            .map(|o| o.status.success())
            .unwrap_or(false);

        if elevated_ok {
            host_log(events, "Firewall UDP rule added via UAC ✓".to_owned());
        } else {
            host_log(
                events,
                format!(
                    "⚠ Не удалось добавить правило файрвола автоматически.\n\
                 Запусти ОДИН РАЗ от Администратора:\n\
                 netsh advfirewall firewall add rule \
                 name=\"{RULE}\" dir=in action=allow protocol=UDP \
                 program=\"{exe}\" enable=yes"
                ),
            );
        }
    }

    #[cfg(not(target_os = "windows"))]
    let _ = events; // suppress unused warning
}

// ═══════════════════════════════════════════════════════════════════════════════
// Registration loop
// ═══════════════════════════════════════════════════════════════════════════════

fn run_host_loop(
    mut config: AppConfig,
    events: Sender<HostEvent>,
    commands: Receiver<HostCommand>,
) {
    // On Windows, ensure an inbound UDP firewall rule exists for this binary.
    // This is needed because Windows Firewall blocks unsolicited inbound UDP
    // from the ID server (hbbs).  The rule is a no-op on subsequent runs once
    // already present.
    setup_udp_firewall(&events);

    loop {
        let _ = events.send(HostEvent::StateChanged(HostState::Connecting));
        host_log(
            &events,
            format!("Connecting to ID server {}…", config.server.id_server),
        );

        match registration_loop(&config, &events, &commands) {
            LoopResult::Stop => {
                let _ = events.send(HostEvent::StateChanged(HostState::Idle));
                return;
            }
            LoopResult::Reconfigure(cfg) => {
                config = cfg;
                host_log(&events, "Config updated — reconnecting.".to_owned());
            }
            LoopResult::Error(e) => {
                let _ = events.send(HostEvent::StateChanged(HostState::Error(e.clone())));
                host_log(&events, format!("Error: {e}  Retrying in 10 s…"));
                let deadline = Instant::now() + Duration::from_secs(10);
                loop {
                    thread::sleep(Duration::from_millis(250));
                    if let Ok(cmd) = commands.try_recv() {
                        match cmd {
                            HostCommand::Stop => {
                                let _ = events.send(HostEvent::StateChanged(HostState::Idle));
                                return;
                            }
                            HostCommand::Reconfigure(cfg) => {
                                config = cfg;
                                break;
                            }
                        }
                    }
                    if Instant::now() >= deadline {
                        break;
                    }
                }
            }
        }
    }
}

enum LoopResult {
    Stop,
    Reconfigure(AppConfig),
    Error(String),
}

fn registration_loop(
    config: &AppConfig,
    events: &Sender<HostEvent>,
    commands: &Receiver<HostCommand>,
) -> LoopResult {
    // ── Self-test: UDP loopback (proves recv_from works on this machine) ─────
    udp_loopback_test(events);

    // ── Self-test: external UDP (proves inbound UDP from internet works) ──────
    udp_internet_test(events);

    // ── TCP probe: see what the server actually does on port 21116 ────────────
    tcp_probe(
        &config.server.id_server,
        RENDEZVOUS_PORT,
        &config.local_id,
        events,
    );

    // ── DNS resolution ────────────────────────────────────────────────────────
    {
        use std::net::ToSocketAddrs;
        let probe = format!("{}:{}", config.server.id_server, RENDEZVOUS_PORT);
        match probe.to_socket_addrs() {
            Ok(it) => {
                let ips: Vec<_> = it.map(|a| a.ip().to_string()).collect();
                host_log(
                    events,
                    format!("DNS {} → [{}]", config.server.id_server, ips.join(", ")),
                );
            }
            Err(e) => {
                return LoopResult::Error(format!(
                    "DNS resolve failed for {}: {e}",
                    config.server.id_server
                ));
            }
        }
    }

    // ── UDP socket ────────────────────────────────────────────────────────────
    // Use a specific bind port if configured (e.g., via --bind-port CLI arg).
    // This lets us reuse the port that was previously registered with hbbs,
    // which can help when the server tracks peers by source IP:port.
    let bind_addr = if config.udp_bind_port > 0 {
        format!("0.0.0.0:{}", config.udp_bind_port)
    } else {
        "0.0.0.0:0".to_owned()
    };
    let socket = match UdpSocket::bind(&bind_addr) {
        Ok(s) => s,
        Err(e) => {
            if config.udp_bind_port > 0 {
                host_log(
                    events,
                    format!(
                        "UDP bind to port {} failed ({e}) — falling back to random port",
                        config.udp_bind_port
                    ),
                );
                match UdpSocket::bind("0.0.0.0:0") {
                    Ok(s) => s,
                    Err(e2) => return LoopResult::Error(format!("UDP bind: {e2}")),
                }
            } else {
                return LoopResult::Error(format!("UDP bind: {e}"));
            }
        }
    };
    socket.set_read_timeout(Some(READ_TIMEOUT_SHORT)).ok();

    // Log the local port so the user can verify the firewall rule covers it.
    if let Ok(local) = socket.local_addr() {
        host_log(events, format!("UDP socket local addr: {local}"));
    }

    let server_addr = format!("{}:{}", config.server.id_server, RENDEZVOUS_PORT);

    // ── Step 1: RegisterPk first (matches actual RustDesk behaviour) ─────────
    //
    // Modern hbbs ignores RegisterPeer from peers whose public key has not
    // been registered yet.  RustDesk logs say:
    //   "register_pk of edesk due to key not confirmed"
    // — it sends RegisterPk proactively WITHOUT waiting for a
    // RegisterPeerResponse(request_pk=true) prompt.
    let pk_bytes = encode_message(&{
        use sha2::{Digest, Sha256};
        // Prefer our stable Ed25519 *sign* public key (we hold the matching
        // secret, so we can complete the secure handshake). Fall back to the
        // explicit --use-everty-keys key, then to a deterministic fake.
        let pk: Vec<u8> = if config.host_sign_pk.len() == 32 {
            host_log(
                events,
                "RegisterPk: using stable Ed25519 sign key".to_owned(),
            );
            config.host_sign_pk.clone()
        } else if config.host_pk.len() == 32 {
            config.host_pk.clone()
        } else {
            let mut h = Sha256::new();
            h.update(b"evertydesk-pk:");
            h.update(config.local_id.as_bytes());
            h.finalize().to_vec()
        };
        let mut hu = Sha256::new();
        hu.update(b"evertydesk-uuid:");
        hu.update(config.local_id.as_bytes());
        let uuid_bytes: Vec<u8> = hu.finalize()[..16].to_vec();
        RendezvousMessage {
            union: Some(rendezvous_message::Union::RegisterPk(RegisterPk {
                id: config.local_id.clone(),
                uuid: uuid_bytes,
                pk,
                old_pk: Vec::new(),
            })),
        }
    });
    host_log(
        events,
        format!(
            "RegisterPk packet: {} bytes  hex={}",
            pk_bytes.len(),
            hex_short(&pk_bytes)
        ),
    );
    if let Err(e) = socket.send_to(&pk_bytes, &server_addr) {
        return LoopResult::Error(format!("RegisterPk send: UDP send_to: {e}"));
    }
    let mut send_count: u32 = 1;
    host_log(
        events,
        format!(
            "RegisterPk sent → {server_addr}  id={}  (#{send_count})",
            config.local_id
        ),
    );

    // ── Step 2: RegisterPeer immediately after ────────────────────────────────
    let reg_bytes = encode_message(&RendezvousMessage {
        union: Some(rendezvous_message::Union::RegisterPeer(RegisterPeer {
            id: config.local_id.clone(),
            serial: 0,
        })),
    });
    host_log(
        events,
        format!(
            "RegisterPeer packet: {} bytes  hex={}",
            reg_bytes.len(),
            hex_short(&reg_bytes)
        ),
    );
    if let Err(e) = socket.send_to(&reg_bytes, &server_addr) {
        return LoopResult::Error(format!("RegisterPeer send: UDP send_to: {e}"));
    }
    send_count += 1;
    host_log(
        events,
        format!(
            "RegisterPeer sent → {server_addr}  id={}  (#{send_count})",
            config.local_id
        ),
    );

    let mut last_hb = Instant::now();
    let mut last_tick = Instant::now();
    let mut buf = vec![0u8; 8192];

    loop {
        // ── Periodic diagnostic tick ──────────────────────────────────────────
        if last_tick.elapsed() >= Duration::from_secs(5) {
            host_log(events, format!(
                "Ожидание ответа от {server_addr} … (отправлено {send_count}×, следующий heartbeat через {:.0}s)",
                HEARTBEAT_INTERVAL.saturating_sub(last_hb.elapsed()).as_secs_f32()
            ));
            last_tick = Instant::now();
        }

        // ── Commands ──────────────────────────────────────────────────────────
        while let Ok(cmd) = commands.try_recv() {
            match cmd {
                HostCommand::Stop => return LoopResult::Stop,
                HostCommand::Reconfigure(cfg) => return LoopResult::Reconfigure(cfg),
            }
        }

        // ── Heartbeat ─────────────────────────────────────────────────────────
        if last_hb.elapsed() >= HEARTBEAT_INTERVAL {
            // Send RegisterPk + RegisterPeer (same as initial registration)
            if let Err(e) = send_register_pk_udp(
                &socket,
                &server_addr,
                &config.local_id,
                &config.host_sign_pk,
            ) {
                return LoopResult::Error(format!("Heartbeat RegisterPk: {e}"));
            }
            send_count += 1;
            if let Err(e) = send_register_peer_udp(&socket, &server_addr, &config.local_id) {
                return LoopResult::Error(format!("Heartbeat RegisterPeer: {e}"));
            }
            send_count += 1;
            host_log(
                events,
                format!("Heartbeat: RegisterPk+RegisterPeer sent → {server_addr} (#{send_count})"),
            );
            last_hb = Instant::now();
        }

        // ── Read incoming UDP datagram from ANY source ────────────────────────
        match socket.recv_from(&mut buf) {
            Ok((len, src)) => {
                host_log(events, format!("UDP recv {len} bytes from {src}"));
                match decode_message(&buf[..len]) {
                    Ok(msg) => match msg.union {
                        Some(rendezvous_message::Union::RegisterPeerResponse(r)) => {
                            host_log(
                                events,
                                format!("RegisterPeerResponse  request_pk={}", r.request_pk),
                            );
                            if r.request_pk {
                                if let Err(e) = send_register_pk_udp(
                                    &socket,
                                    &server_addr,
                                    &config.local_id,
                                    &config.host_sign_pk,
                                ) {
                                    return LoopResult::Error(format!("RegisterPk: {e}"));
                                }
                                host_log(events, "RegisterPk sent".to_owned());
                            } else {
                                host_log(events, "Registered ✓ (key already on server)".to_owned());
                                let _ = events.send(HostEvent::Registered { request_pk: false });
                                let _ = events.send(HostEvent::StateChanged(HostState::Ready));
                            }
                        }
                        Some(rendezvous_message::Union::RegisterPkResponse(r)) => {
                            host_log(events, format!("RegisterPkResponse  result={}", r.result));
                            if r.result == 0 {
                                host_log(
                                    events,
                                    "Public key accepted — host is online ✓".to_owned(),
                                );
                                let _ = events.send(HostEvent::Registered { request_pk: true });
                                let _ = events.send(HostEvent::StateChanged(HostState::Ready));
                            } else {
                                return LoopResult::Error(format!(
                                    "RegisterPk rejected (result={})",
                                    r.result
                                ));
                            }
                        }
                        other => {
                            let msg2 = RendezvousMessage { union: other };
                            if let Some(r) = handle_rendezvous_msg(msg2, config, events) {
                                return r;
                            }
                        }
                    },
                    Err(e) => host_log(events, format!("Decode error ({len}B from {src}): {e}")),
                }
            }
            Err(ref e)
                if e.kind() == std::io::ErrorKind::WouldBlock
                    || e.kind() == std::io::ErrorKind::TimedOut => {}
            Err(e) => return LoopResult::Error(format!("UDP recv_from: {e}")),
        }
    }
}

fn handle_rendezvous_msg(
    msg: RendezvousMessage,
    config: &AppConfig,
    events: &Sender<HostEvent>,
) -> Option<LoopResult> {
    match msg.union {
        Some(rendezvous_message::Union::RegisterPeerResponse(r)) => {
            host_log(events, format!("Registered ✓  request_pk={}", r.request_pk));
            let _ = events.send(HostEvent::Registered {
                request_pk: r.request_pk,
            });
            let _ = events.send(HostEvent::StateChanged(HostState::Ready));
            None
        }

        // Relay-based incoming connection request.
        Some(rendezvous_message::Union::RequestRelay(req)) => {
            let relay = if req.relay_server.is_empty() {
                config.server.relay_server.clone()
            } else {
                req.relay_server.clone()
            };
            host_log(
                events,
                format!(
                    "RequestRelay incoming target={} relay={relay} uuid={}",
                    req.id, req.uuid
                ),
            );
            send_relay_response(
                config,
                events,
                req.socket_addr.clone(),
                relay.clone(),
                req.uuid.clone(),
            );
            let _ = events.send(HostEvent::StateChanged(HostState::Accepting(
                req.id.clone(),
            )));
            let _ = events.send(HostEvent::IncomingRequest {
                peer_id: req.id.clone(),
                relay_server: relay.clone(),
                uuid: req.uuid.clone(),
            });

            // Spawn relay session.
            let cfg = config.clone();
            let evs = events.clone();
            let peer_id = req.id.clone();
            let uuid = req.uuid.clone();
            thread::spawn(move || {
                handle_relay_session(cfg, evs, peer_id, relay, uuid);
            });
            None
        }

        // ── Standard incoming connection: server tells host a peer wants in ──
        // We always go through the relay (firewall-proof), regardless of the
        // direct-punch hint, so it works on any network.
        Some(rendezvous_message::Union::PunchHole(ph)) => {
            let relay_server = if ph.relay_server.is_empty() {
                config.server.relay_server.clone()
            } else {
                ph.relay_server.clone()
            };
            host_log(
                events,
                format!(
                    "PunchHole incoming  relay={relay_server} force_relay={}",
                    ph.force_relay
                ),
            );
            create_relay(config, events, ph.socket_addr, relay_server);
            None
        }

        // LAN peer asking for local address — just relay it too (universal).
        Some(rendezvous_message::Union::FetchLocalAddr(fla)) => {
            let relay_server = if fla.relay_server.is_empty() {
                config.server.relay_server.clone()
            } else {
                fla.relay_server.clone()
            };
            host_log(
                events,
                format!("FetchLocalAddr incoming  relay={relay_server}"),
            );
            create_relay(config, events, fla.socket_addr, relay_server);
            None
        }

        Some(rendezvous_message::Union::PunchHoleRequest(req)) => {
            host_log(events, format!("PunchHoleRequest id={}", req.id));
            None
        }

        _ => None,
    }
}

/// Host side of an incoming relay connection.
///
/// 1. Opens a fresh TCP connection to the rendezvous server and sends a
///    `RelayResponse` so the server can tell the peer which relay + uuid to
///    use.
/// 2. Spawns the relay session: connects to the relay server, identifies by
///    uuid, runs the auth handshake, then captures / encodes / streams.
fn send_relay_response(
    config: &AppConfig,
    events: &Sender<HostEvent>,
    peer_socket_addr: Vec<u8>,
    relay_server: String,
    uuid: String,
) {
    let id_server = config.server.id_server.clone();
    match connect_tcp(&id_server, RENDEZVOUS_PORT) {
        Ok(mut sock) => {
            let resp = RendezvousMessage {
                union: Some(rendezvous_message::Union::RelayResponse(RelayResponse {
                    socket_addr: peer_socket_addr,
                    uuid: uuid.clone(),
                    relay_server: relay_server.clone(),
                    id: config.local_id.clone(),
                    version: "1.4.6".to_owned(),
                    ..Default::default()
                })),
            };
            if let Err(e) = send_framed(&mut sock, &encode_message(&resp)) {
                host_log(events, format!("RelayResponse send failed: {e}"));
            } else {
                host_log(
                    events,
                    format!("RelayResponse sent → {id_server} (uuid={uuid})"),
                );
            }
        }
        Err(e) => {
            host_log(
                events,
                format!("RelayResponse: connect rendezvous failed: {e}"),
            );
        }
    }
}

fn create_relay(
    config: &AppConfig,
    events: &Sender<HostEvent>,
    peer_socket_addr: Vec<u8>,
    relay_server: String,
) {
    let uuid = uuid::Uuid::new_v4().to_string();

    // ── Step 1: tell the rendezvous server about the relay reservation ───────
    let id_server = config.server.id_server.clone();
    match connect_tcp(&id_server, RENDEZVOUS_PORT) {
        Ok(mut sock) => {
            let resp = RendezvousMessage {
                union: Some(rendezvous_message::Union::RelayResponse(RelayResponse {
                    socket_addr: peer_socket_addr,
                    uuid: uuid.clone(),
                    relay_server: relay_server.clone(),
                    id: config.local_id.clone(),
                    version: "1.4.6".to_owned(),
                    ..Default::default()
                })),
            };
            if let Err(e) = send_framed(&mut sock, &encode_message(&resp)) {
                host_log(events, format!("RelayResponse send failed: {e}"));
            } else {
                host_log(
                    events,
                    format!("RelayResponse sent → {id_server} (uuid={uuid})"),
                );
            }
        }
        Err(e) => {
            host_log(
                events,
                format!("create_relay: connect rendezvous failed: {e}"),
            );
            return;
        }
    }

    // ── Step 2: spawn the host-side relay session ────────────────────────────
    let _ = events.send(HostEvent::StateChanged(HostState::Accepting(uuid.clone())));
    let cfg = config.clone();
    let evs = events.clone();
    let peer_id = "(relay)".to_owned();
    thread::spawn(move || {
        handle_relay_session(cfg, evs, peer_id, relay_server, uuid);
    });
}

// ═══════════════════════════════════════════════════════════════════════════════
// Relay session — auth + capture + stream + input injection
// ═══════════════════════════════════════════════════════════════════════════════

fn handle_relay_session(
    config: AppConfig,
    events: Sender<HostEvent>,
    peer_id: String,
    relay_server: String,
    uuid: String,
) {
    match relay_session_inner(&config, &events, &peer_id, &relay_server, &uuid) {
        Ok(()) => {
            host_log(&events, format!("Session with {peer_id} ended normally."));
        }
        Err(e) => {
            host_log(&events, format!("Session with {peer_id} error: {e}"));
        }
    }
    let _ = events.send(HostEvent::SessionEnded {
        peer_id: peer_id.clone(),
        reason: String::new(),
    });
    let _ = events.send(HostEvent::StateChanged(HostState::Ready));
}

fn relay_session_inner(
    config: &AppConfig,
    events: &Sender<HostEvent>,
    peer_id: &str,
    relay_server: &str,
    uuid: &str,
) -> Result<(), String> {
    // ── 1. Connect to relay ───────────────────────────────────────────────────
    host_log(events, format!("Connecting to relay {relay_server}…"));
    let mut relay =
        connect_tcp(relay_server, RELAY_PORT).map_err(|e| format!("Relay connect: {e}"))?;

    // Identify ourselves to the relay — EXACTLY as RustDesk's
    // create_relay_connection_ does: only `licence_key` (server public key)
    // and `uuid`, everything else default/empty. Extra fields (id, secure)
    // break pairing on hbbr.
    let id_msg = RendezvousMessage {
        union: Some(rendezvous_message::Union::RequestRelay(RequestRelay {
            licence_key: config.server.public_key.clone(),
            uuid: uuid.to_owned(),
            id: String::new(),
            relay_server: String::new(),
            secure: false,
            conn_type: 0,
            token: String::new(),
            socket_addr: Vec::new(),
        })),
    };
    send_framed(&mut relay, &encode_message(&id_msg))?;
    host_log(events, "Relay identified.".to_owned());

    relay
        .set_read_timeout(Some(READ_TIMEOUT_AUTH))
        .map_err(|e| format!("set_read_timeout: {e}"))?;

    // ── 2. Secure handshake (RustDesk relay connections are always secure) ────
    // Sign IdPk{ id, ephemeral_box_pk } with our stable Ed25519 key and send it
    // as SignedId. The peer verifies it with our registered public key, seals a
    // symmetric key to our box pk, and replies PublicKey. From then on the
    // stream is secretbox-encrypted.
    let mut cipher: Option<StreamCipher> = None;
    {
        let (box_pk, box_sk) = crypto::gen_box_keypair();
        let id_pk = IdPk {
            id: config.local_id.clone(),
            pk: box_pk,
        };
        let signed = crypto::sign(&id_pk.encode_to_vec(), &config.host_sign_sk)
            .ok_or_else(|| "Failed to sign IdPk (bad sign secret key)".to_owned())?;
        let signed_id = PeerMessage {
            union: Some(peer_message::Union::SignedId(SignedId { id: signed })),
        };
        send_framed(&mut relay, &encode_peer_message(&signed_id))?;
        host_log(
            events,
            "Secure handshake: SignedId sent, awaiting PublicKey…".to_owned(),
        );

        // Read the peer's PublicKey (still plaintext). Skip keepalives.
        let mut tries = 0u32;
        loop {
            let payload = read_framed(&mut relay).map_err(|e| format!("Handshake read: {e}"))?;
            if payload.is_empty() {
                let _ = relay.write_all(&encode_frame_len(0)?);
                tries += 1;
                if tries > 200 {
                    return Err("Handshake: only keepalives, no PublicKey".to_owned());
                }
                continue;
            }
            let msg = decode_peer_message(&payload).map_err(|e| format!("Peer decode: {e}"))?;
            match msg.union {
                Some(peer_message::Union::PublicKey(pk)) => {
                    if pk.asymmetric_value.is_empty() {
                        host_log(
                            events,
                            "Peer chose insecure (empty PublicKey) — plaintext".to_owned(),
                        );
                    } else if let Some(symkey) = crypto::open_symmetric_key(
                        &pk.symmetric_value,
                        &pk.asymmetric_value,
                        &box_sk,
                    ) {
                        cipher = StreamCipher::new(&symkey);
                        host_log(events, "Secure channel established ✓".to_owned());
                    } else {
                        return Err("Failed to open peer symmetric key".to_owned());
                    }
                    break;
                }
                other => {
                    host_log(
                        events,
                        format!("Handshake: unexpected {}", peer_msg_kind(&other)),
                    );
                    tries += 1;
                    if tries > 20 {
                        return Err("Handshake: no PublicKey".to_owned());
                    }
                }
            }
        }
    }

    // ── 3. Auth: send Hash (encrypted), verify LoginRequest ───────────────────
    let salt = format!("{:016x}", random_u64());
    let challenge = format!("{:016x}", random_u64());

    let hash_msg = PeerMessage {
        union: Some(peer_message::Union::Hash(Hash {
            salt: salt.clone(),
            challenge: challenge.clone(),
        })),
    };
    send_peer_enc(&mut relay, &mut cipher, &hash_msg)?;

    // Wait for a LoginRequest with a valid password. On empty/wrong password
    // we send the RustDesk-standard error ("Empty Password" / "Wrong Password")
    // and KEEP the connection open so the peer prompts and retries — closing
    // here is what made the phone show "wrong password" with no input box.
    let mut others = 0u32;
    let mut pw_attempts = 0u32;
    let _login = loop {
        let msg = match recv_peer_enc(&mut relay, &mut cipher) {
            Ok(Some(m)) => m,
            Ok(None) => continue, // keepalive
            Err(e) => {
                return Err(format!("Relay read before login: {e}"));
            }
        };
        match msg.union {
            Some(peer_message::Union::LoginRequest(lr)) => {
                if lr.password.is_empty() {
                    host_log(
                        events,
                        "Login probe (empty password) → requesting password".to_owned(),
                    );
                    send_login_error(&mut relay, &mut cipher, "Empty Password")?;
                    pw_attempts += 1;
                } else if verify_password(&lr.password, &config.local_password, &salt, &challenge) {
                    host_log(events, "Password OK ✓".to_owned());
                    break lr;
                } else {
                    host_log(events, "Wrong password → asking to retry".to_owned());
                    send_login_error(&mut relay, &mut cipher, "Wrong Password")?;
                    pw_attempts += 1;
                }
                if pw_attempts > 10 {
                    return Err("Too many wrong-password attempts".to_owned());
                }
            }
            Some(peer_message::Union::TestDelay(d)) => {
                // Echo test delay back so the client's RTT probe completes.
                let mut d = d;
                d.from_client = false;
                let reply = PeerMessage {
                    union: Some(peer_message::Union::TestDelay(d)),
                };
                let _ = send_peer_enc(&mut relay, &mut cipher, &reply);
            }
            other => {
                others += 1;
                host_log(
                    events,
                    format!("Pre-login peer message: {}", peer_msg_kind(&other)),
                );
                if others > 40 {
                    return Err("Too many non-login messages".to_owned());
                }
            }
        }
    };

    // ── 4. Send LoginResponse + display info ─────────────────────────────────
    let (screen_w, screen_h) = crate::capture::screen_size().unwrap_or((1920, 1080));
    let hostname = hostname();
    let peer_info = PeerInfo {
        username: String::new(),
        hostname: hostname.clone(),
        platform: std::env::consts::OS.to_owned(),
        version: "1.4.6".to_owned(),
        current_display: 0,
        displays: vec![DisplayInfo {
            x: 0,
            y: 0,
            width: screen_w as i32,
            height: screen_h as i32,
            name: hostname,
            online: true,
            cursor_embedded: false,
            scale: 1.0,
        }],
        windows_sessions: None,
    };
    let login_ok = PeerMessage {
        union: Some(peer_message::Union::LoginResponse(LoginResponse {
            union: Some(login_response::Union::PeerInfo(peer_info)),
        })),
    };
    send_peer_enc(&mut relay, &mut cipher, &login_ok)?;

    host_log(events, format!("Auth OK for {peer_id}. Starting capture…"));
    let _ = events.send(HostEvent::SessionStarted {
        peer_id: peer_id.to_owned(),
    });

    // ── 4. Two-thread session: video writer + input reader ───────────────────
    // Decoupling them keeps the remote cursor responsive even while a frame is
    // being captured / encoded / sent (which used to block input handling).
    let (send_cipher, recv_cipher) = match cipher.take() {
        Some(c) => {
            let (s, r) = c.into_halves();
            (Some(s), Some(r))
        }
        None => (None, None),
    };

    let write_stream = relay
        .try_clone()
        .map_err(|e| format!("try_clone relay stream: {e}"))?;
    let stop = Arc::new(AtomicBool::new(false));

    // ── Video thread ──────────────────────────────────────────────────────────
    let stop_v = stop.clone();
    let video_handle = thread::spawn(move || {
        video_loop(write_stream, send_cipher, stop_v);
    });

    // ── Input loop (this thread) ──────────────────────────────────────────────
    // A 1 s read timeout lets us notice the stop flag without busy-waiting.
    let _ = relay.set_read_timeout(Some(Duration::from_secs(1)));
    let mut recv_cipher = recv_cipher;
    while !stop.load(Ordering::Relaxed) {
        match recv_peer_rc(&mut relay, &mut recv_cipher) {
            Ok(Some(msg)) => handle_client_input(msg),
            Ok(None) => {}
            Err(ref e) if is_timeout(e) => {}
            Err(_) => break, // disconnected
        }
    }
    stop.store(true, Ordering::Relaxed);
    let _ = video_handle.join();

    // Release any mouse buttons that may be stuck down (the session could end
    // mid-click), so the local desktop stays usable.
    release_stuck_input();

    Ok(())
}

/// Capture + encode + stream loop, run on its own thread.
fn video_loop(
    mut stream: TcpStream,
    mut send_cipher: Option<crate::crypto::SendCipher>,
    stop: std::sync::Arc<std::sync::atomic::AtomicBool>,
) {
    use std::sync::atomic::Ordering;

    #[cfg(feature = "live-h264")]
    let mut encoder = {
        use openh264::encoder::{Encoder, EncoderConfig, UsageType};
        let cfg = EncoderConfig::new().usage_type(UsageType::ScreenContentRealTime);
        let api = openh264::OpenH264API::from_source();
        match Encoder::with_api_config(api, cfg) {
            Ok(e) => Some(e),
            Err(_) => {
                stop.store(true, Ordering::Relaxed);
                return;
            }
        }
    };
    #[cfg(not(feature = "live-h264"))]
    let mut encoder: Option<()> = None;

    let mut frame_idx: u64 = 0;
    let mut last_frame = Instant::now();

    while !stop.load(Ordering::Relaxed) {
        if last_frame.elapsed() < FRAME_BUDGET {
            thread::sleep(Duration::from_millis(2));
            continue;
        }
        last_frame = Instant::now();
        frame_idx += 1;

        let Some((cap_w, cap_h, bgra)) = crate::capture::capture_screen() else {
            thread::sleep(FRAME_BUDGET);
            continue;
        };

        // Encode at native resolution (downscaling broke decoding on the phone
        // when the stream size differed from the announced DisplayInfo).
        let is_key = frame_idx % 60 == 1;
        let h264_bytes = encode_h264_frame(
            #[cfg(feature = "live-h264")]
            encoder.as_mut(),
            #[cfg(not(feature = "live-h264"))]
            &mut encoder,
            cap_w,
            cap_h,
            &bgra,
            is_key,
        );

        if let Some(bytes) = h264_bytes {
            let frame_msg = PeerMessage {
                union: Some(peer_message::Union::VideoFrame(VideoFrame {
                    union: Some(video_frame::Union::H264s(EncodedVideoFrames {
                        frames: vec![EncodedVideoFrame {
                            data: bytes,
                            key: is_key,
                            ..Default::default()
                        }],
                    })),
                    display: 0,
                })),
            };
            let mut payload = encode_peer_message(&frame_msg);
            if let Some(c) = send_cipher.as_mut() {
                payload = c.encrypt(&payload);
            }
            if send_framed(&mut stream, &payload).is_err() {
                break;
            }
        }
    }
    stop.store(true, Ordering::Relaxed);
}

/// Read a PeerMessage using the receive-only cipher half.
fn recv_peer_rc(
    stream: &mut TcpStream,
    cipher: &mut Option<crate::crypto::RecvCipher>,
) -> Result<Option<PeerMessage>, String> {
    let payload = read_framed(stream)?;
    if payload.is_empty() {
        return Ok(None);
    }
    let plain = if let Some(c) = cipher.as_mut() {
        c.decrypt(&payload)?
    } else {
        payload
    };
    let msg = decode_peer_message(&plain).map_err(|e| format!("Peer decode: {e}"))?;
    Ok(Some(msg))
}

// ── H264 encoding ─────────────────────────────────────────────────────────────

#[cfg(feature = "live-h264")]
fn encode_h264_frame(
    encoder: Option<&mut openh264::encoder::Encoder>,
    w: u32,
    h: u32,
    bgra: &[u8],
    _key: bool,
) -> Option<Vec<u8>> {
    let enc = encoder?;
    let yuv = bgra_to_yuv420(w as usize, h as usize, bgra);
    let bitstream = enc.encode(&yuv).ok()?;
    let mut out = Vec::new();
    for i in 0..bitstream.num_layers() {
        if let Some(layer) = bitstream.layer(i) {
            for j in 0..layer.nal_count() {
                if let Some(nal) = layer.nal_unit(j) {
                    out.extend_from_slice(nal);
                }
            }
        }
    }
    if out.is_empty() {
        None
    } else {
        Some(out)
    }
}

#[cfg(not(feature = "live-h264"))]
fn encode_h264_frame(
    _encoder: &mut Option<()>,
    _w: u32,
    _h: u32,
    _bgra: &[u8],
    _key: bool,
) -> Option<Vec<u8>> {
    None
}

// ── YUV conversion ────────────────────────────────────────────────────────────

#[cfg(feature = "live-h264")]
struct YuvFrame {
    width: usize,
    height: usize,
    y: Vec<u8>,
    u: Vec<u8>,
    v: Vec<u8>,
}

#[cfg(feature = "live-h264")]
impl openh264::formats::YUVSource for YuvFrame {
    fn dimensions(&self) -> (usize, usize) {
        (self.width, self.height)
    }
    fn strides(&self) -> (usize, usize, usize) {
        (self.width, self.width / 2, self.width / 2)
    }
    fn y(&self) -> &[u8] {
        &self.y
    }
    fn u(&self) -> &[u8] {
        &self.u
    }
    fn v(&self) -> &[u8] {
        &self.v
    }
}

/// BGRA (GDI output) → planar YUV420 (BT.601 limited range).
#[cfg(feature = "live-h264")]
fn bgra_to_yuv420(w: usize, h: usize, bgra: &[u8]) -> YuvFrame {
    let mut y_plane = vec![0u8; w * h];
    let mut u_plane = vec![0u8; (w / 2) * (h / 2)];
    let mut v_plane = vec![0u8; (w / 2) * (h / 2)];

    for row in 0..h {
        for col in 0..w {
            let base = (row * w + col) * 4;
            let b = bgra[base] as i32;
            let g = bgra[base + 1] as i32;
            let r = bgra[base + 2] as i32;

            // BT.601 limited range
            let y = ((66 * r + 129 * g + 25 * b + 128) >> 8) + 16;
            y_plane[row * w + col] = y.clamp(16, 235) as u8;

            if row % 2 == 0 && col % 2 == 0 {
                let u = ((-38 * r - 74 * g + 112 * b + 128) >> 8) + 128;
                let v = ((112 * r - 94 * g - 18 * b + 128) >> 8) + 128;
                let idx = (row / 2) * (w / 2) + (col / 2);
                u_plane[idx] = u.clamp(16, 240) as u8;
                v_plane[idx] = v.clamp(16, 240) as u8;
            }
        }
    }

    YuvFrame {
        width: w,
        height: h,
        y: y_plane,
        u: u_plane,
        v: v_plane,
    }
}

// ── Input injection ───────────────────────────────────────────────────────────

fn handle_client_input(msg: PeerMessage) {
    match msg.union {
        Some(peer_message::Union::MouseEvent(ev)) => inject_mouse(ev),
        Some(peer_message::Union::KeyEvent(ev)) => inject_key(ev),
        _ => {}
    }
}

/// Release mouse buttons (and common modifier keys) that may have been left
/// "down" when a session ended mid-click — otherwise the local desktop becomes
/// unusable (e.g. Start menu not clickable).
#[cfg(all(target_os = "windows", feature = "live-vp9-mf"))]
fn release_stuck_input() {
    use std::mem::size_of;
    use windows::Win32::UI::Input::KeyboardAndMouse::{
        SendInput, INPUT, INPUT_0, INPUT_KEYBOARD, INPUT_MOUSE, KEYBDINPUT, KEYEVENTF_KEYUP,
        MOUSEEVENTF_LEFTUP, MOUSEEVENTF_MIDDLEUP, MOUSEEVENTF_RIGHTUP, MOUSEINPUT, VIRTUAL_KEY,
    };
    unsafe {
        let mouse_up = MOUSEEVENTF_LEFTUP | MOUSEEVENTF_RIGHTUP | MOUSEEVENTF_MIDDLEUP;
        let mi = MOUSEINPUT {
            dx: 0,
            dy: 0,
            mouseData: 0,
            dwFlags: mouse_up,
            time: 0,
            dwExtraInfo: 0,
        };
        let m_input = INPUT {
            r#type: INPUT_MOUSE,
            Anonymous: INPUT_0 { mi },
        };
        SendInput(&[m_input], size_of::<INPUT>() as i32);

        // Release common modifiers: Ctrl(0x11), Alt(0x12), Shift(0x10), Win(0x5B/0x5C).
        for vk in [0x11u16, 0x12, 0x10, 0x5B, 0x5C] {
            let ki = KEYBDINPUT {
                wVk: VIRTUAL_KEY(vk),
                wScan: 0,
                dwFlags: KEYEVENTF_KEYUP,
                time: 0,
                dwExtraInfo: 0,
            };
            let k_input = INPUT {
                r#type: INPUT_KEYBOARD,
                Anonymous: INPUT_0 { ki },
            };
            SendInput(&[k_input], size_of::<INPUT>() as i32);
        }
    }
}

#[cfg(all(
    not(target_os = "linux"),
    not(all(target_os = "windows", feature = "live-vp9-mf"))
))]
fn release_stuck_input() {}

#[cfg(all(target_os = "windows", feature = "live-vp9-mf"))]
fn inject_mouse(ev: crate::rustdesk_proto::MouseEvent) {
    use windows::Win32::UI::Input::KeyboardAndMouse::{
        MOUSEEVENTF_ABSOLUTE, MOUSEEVENTF_HWHEEL, MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP,
        MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP, MOUSEEVENTF_MOVE, MOUSEEVENTF_RIGHTDOWN,
        MOUSEEVENTF_RIGHTUP, MOUSEEVENTF_WHEEL, MOUSEEVENTF_XDOWN, MOUSEEVENTF_XUP,
    };
    use windows::Win32::UI::WindowsAndMessaging::{GetSystemMetrics, SM_CXSCREEN, SM_CYSCREEN};

    // XBUTTON1 = 0x0001 (back), XBUTTON2 = 0x0002 (forward) — for mouseData.
    const XBUTTON1: i32 = 0x0001;
    const XBUTTON2: i32 = 0x0002;

    // RustDesk mouse mask encoding:  mask = (button << 3) | event_type
    //   event_type:  0 = move, 1 = button down, 2 = button up, 3 = wheel
    //   button:      1 = left, 2 = right, 4 = middle(wheel), 8 = back, 16 = forward
    const EVT_MOVE: i32 = 0;
    const EVT_DOWN: i32 = 1;
    const EVT_UP: i32 = 2;
    const EVT_WHEEL: i32 = 3;
    const BTN_LEFT: i32 = 1;
    const BTN_RIGHT: i32 = 2;
    const BTN_MIDDLE: i32 = 4;
    const BTN_BACK: i32 = 8;
    const BTN_FORWARD: i32 = 16;

    let evt_type = ev.mask & 0x7;
    let button = ev.mask >> 3;

    unsafe {
        let sw = GetSystemMetrics(SM_CXSCREEN).max(1) as i32;
        let sh = GetSystemMetrics(SM_CYSCREEN).max(1) as i32;

        // ── Wheel: ev.x / ev.y carry scroll deltas, not coordinates ──────────
        if evt_type == EVT_WHEEL {
            if ev.y != 0 {
                send_mouse_raw(MOUSEEVENTF_WHEEL, 0, 0, ev.y * 120);
            }
            if ev.x != 0 {
                send_mouse_raw(MOUSEEVENTF_HWHEEL, 0, 0, ev.x * 120);
            }
            return;
        }

        // ── Move / down / up: ev.x, ev.y are absolute screen coordinates ─────
        // Only reposition the cursor for move events, or for down/up that carry
        // real coordinates. Some clients send button events with (0,0) — moving
        // there first made every click jump to the top-left corner.
        let abs_x = (ev.x * 65535 / sw).clamp(0, 65535);
        let abs_y = (ev.y * 65535 / sh).clamp(0, 65535);
        let do_move = evt_type == EVT_MOVE || ev.x != 0 || ev.y != 0;
        let mut flags = if do_move {
            MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE
        } else {
            windows::Win32::UI::Input::KeyboardAndMouse::MOUSE_EVENT_FLAGS::default()
        };
        let mut mouse_data: i32 = 0;

        match evt_type {
            EVT_MOVE => {}
            EVT_DOWN => match button {
                BTN_LEFT => flags |= MOUSEEVENTF_LEFTDOWN,
                BTN_RIGHT => flags |= MOUSEEVENTF_RIGHTDOWN,
                BTN_MIDDLE => flags |= MOUSEEVENTF_MIDDLEDOWN,
                BTN_BACK => {
                    flags |= MOUSEEVENTF_XDOWN;
                    mouse_data = XBUTTON1;
                }
                BTN_FORWARD => {
                    flags |= MOUSEEVENTF_XDOWN;
                    mouse_data = XBUTTON2;
                }
                _ => {}
            },
            EVT_UP => match button {
                BTN_LEFT => flags |= MOUSEEVENTF_LEFTUP,
                BTN_RIGHT => flags |= MOUSEEVENTF_RIGHTUP,
                BTN_MIDDLE => flags |= MOUSEEVENTF_MIDDLEUP,
                BTN_BACK => {
                    flags |= MOUSEEVENTF_XUP;
                    mouse_data = XBUTTON1;
                }
                BTN_FORWARD => {
                    flags |= MOUSEEVENTF_XUP;
                    mouse_data = XBUTTON2;
                }
                _ => {}
            },
            _ => {}
        }

        let (dx, dy) = if do_move { (abs_x, abs_y) } else { (0, 0) };
        send_mouse_raw(flags, dx, dy, mouse_data);
    }
}

/// Low-level SendInput wrapper for a single mouse event.
#[cfg(all(target_os = "windows", feature = "live-vp9-mf"))]
unsafe fn send_mouse_raw(
    flags: windows::Win32::UI::Input::KeyboardAndMouse::MOUSE_EVENT_FLAGS,
    dx: i32,
    dy: i32,
    mouse_data: i32,
) {
    use std::mem::size_of;
    use windows::Win32::UI::Input::KeyboardAndMouse::{
        SendInput, INPUT, INPUT_0, INPUT_MOUSE, MOUSEINPUT,
    };
    let mi = MOUSEINPUT {
        dx,
        dy,
        mouseData: mouse_data,
        dwFlags: flags,
        time: 0,
        dwExtraInfo: 0,
    };
    let input = INPUT {
        r#type: INPUT_MOUSE,
        Anonymous: INPUT_0 { mi },
    };
    SendInput(&[input], size_of::<INPUT>() as i32);
}

#[cfg(target_os = "linux")]
fn release_stuck_input() {
    linux_xtest::release_stuck_input();
}

#[cfg(all(
    not(target_os = "linux"),
    not(all(target_os = "windows", feature = "live-vp9-mf"))
))]
fn inject_mouse(_ev: crate::rustdesk_proto::MouseEvent) {}

#[cfg(all(target_os = "windows", feature = "live-vp9-mf"))]
fn inject_key(ev: crate::rustdesk_proto::KeyEvent) {
    use std::mem::size_of;
    use windows::Win32::UI::Input::KeyboardAndMouse::{
        SendInput, INPUT, INPUT_0, INPUT_KEYBOARD, KEYBDINPUT, KEYEVENTF_KEYUP, VIRTUAL_KEY,
    };

    use windows::Win32::UI::Input::KeyboardAndMouse::KEYEVENTF_UNICODE;

    unsafe {
        match &ev.union {
            // ── Control / named keys → virtual-key code ──────────────────────
            Some(crate::rustdesk_proto::key_event::Union::ControlKey(ck)) => {
                let vk = control_key_to_vk(*ck);
                if vk == 0 {
                    return;
                }
                let mut flags =
                    windows::Win32::UI::Input::KeyboardAndMouse::KEYBD_EVENT_FLAGS::default();
                let key_up = !ev.down && !ev.press;
                if ev.press {
                    // press = down then up
                    send_key_vk(vk, false);
                    send_key_vk(vk, true);
                    return;
                }
                if key_up {
                    flags |= KEYEVENTF_KEYUP;
                }
                let ki = KEYBDINPUT {
                    wVk: VIRTUAL_KEY(vk),
                    wScan: 0,
                    dwFlags: flags,
                    time: 0,
                    dwExtraInfo: 0,
                };
                let input = INPUT {
                    r#type: INPUT_KEYBOARD,
                    Anonymous: INPUT_0 { ki },
                };
                SendInput(&[input], size_of::<INPUT>() as i32);
            }
            // ── Unicode character → KEYEVENTF_UNICODE (layout-independent) ────
            // This types the exact character the remote user pressed regardless
            // of the local keyboard layout (handles Cyrillic, symbols, etc.).
            Some(crate::rustdesk_proto::key_event::Union::Unicode(ch)) => {
                let Some(c) = char::from_u32(*ch) else { return };
                let mut buf = [0u16; 2];
                for unit in c.encode_utf16(&mut buf).iter() {
                    // down
                    let ki = KEYBDINPUT {
                        wVk: VIRTUAL_KEY(0),
                        wScan: *unit,
                        dwFlags: KEYEVENTF_UNICODE,
                        time: 0,
                        dwExtraInfo: 0,
                    };
                    SendInput(
                        &[INPUT {
                            r#type: INPUT_KEYBOARD,
                            Anonymous: INPUT_0 { ki },
                        }],
                        size_of::<INPUT>() as i32,
                    );
                    // up
                    let ki_up = KEYBDINPUT {
                        wVk: VIRTUAL_KEY(0),
                        wScan: *unit,
                        dwFlags: KEYEVENTF_UNICODE | KEYEVENTF_KEYUP,
                        time: 0,
                        dwExtraInfo: 0,
                    };
                    SendInput(
                        &[INPUT {
                            r#type: INPUT_KEYBOARD,
                            Anonymous: INPUT_0 { ki: ki_up },
                        }],
                        size_of::<INPUT>() as i32,
                    );
                }
            }
            None => {}
        }
    }
}

/// Send a single virtual-key down or up event.
#[cfg(all(target_os = "windows", feature = "live-vp9-mf"))]
unsafe fn send_key_vk(vk: u16, up: bool) {
    use std::mem::size_of;
    use windows::Win32::UI::Input::KeyboardAndMouse::{
        SendInput, INPUT, INPUT_0, INPUT_KEYBOARD, KEYBDINPUT, KEYBD_EVENT_FLAGS, KEYEVENTF_KEYUP,
        VIRTUAL_KEY,
    };
    let flags = if up {
        KEYEVENTF_KEYUP
    } else {
        KEYBD_EVENT_FLAGS::default()
    };
    let ki = KEYBDINPUT {
        wVk: VIRTUAL_KEY(vk),
        wScan: 0,
        dwFlags: flags,
        time: 0,
        dwExtraInfo: 0,
    };
    SendInput(
        &[INPUT {
            r#type: INPUT_KEYBOARD,
            Anonymous: INPUT_0 { ki },
        }],
        size_of::<INPUT>() as i32,
    );
}

#[cfg(target_os = "linux")]
fn inject_mouse(ev: crate::rustdesk_proto::MouseEvent) {
    linux_xtest::inject_mouse(ev);
}

#[cfg(target_os = "linux")]
fn inject_key(ev: crate::rustdesk_proto::KeyEvent) {
    linux_xtest::inject_key(ev);
}

#[cfg(all(
    not(target_os = "linux"),
    not(all(target_os = "windows", feature = "live-vp9-mf"))
))]
fn inject_key(_ev: crate::rustdesk_proto::KeyEvent) {}

#[cfg(target_os = "linux")]
mod linux_xtest {
    use x11rb::{
        connection::Connection,
        protocol::{xproto, xtest::ConnectionExt as XtestConnectionExt},
    };

    const EVT_MOVE: i32 = 0;
    const EVT_DOWN: i32 = 1;
    const EVT_UP: i32 = 2;
    const EVT_WHEEL: i32 = 3;
    const BTN_LEFT: i32 = 1;
    const BTN_RIGHT: i32 = 2;
    const BTN_MIDDLE: i32 = 4;

    pub fn inject_mouse(ev: crate::rustdesk_proto::MouseEvent) {
        let Ok((conn, screen_num)) = x11rb::connect(None) else {
            return;
        };
        let screen = &conn.setup().roots[screen_num];
        let root = screen.root;
        let evt_type = ev.mask & 0x7;
        let button = ev.mask >> 3;

        match evt_type {
            EVT_MOVE => {
                let _ = conn.xtest_fake_input(
                    xproto::MOTION_NOTIFY_EVENT,
                    0,
                    0,
                    root,
                    clamp_i16(ev.x),
                    clamp_i16(ev.y),
                    0,
                );
            }
            EVT_DOWN | EVT_UP => {
                if ev.x != 0 || ev.y != 0 {
                    let _ = conn.xtest_fake_input(
                        xproto::MOTION_NOTIFY_EVENT,
                        0,
                        0,
                        root,
                        clamp_i16(ev.x),
                        clamp_i16(ev.y),
                        0,
                    );
                }
                if let Some(detail) = mouse_button_detail(button) {
                    if evt_type == EVT_DOWN {
                        // For remote-control UX a press must immediately focus/click
                        // the target window. The matching release may arrive later;
                        // sending it twice is harmless on X11 and fixes "hover works,
                        // click does not" on conservative desktops.
                        click_button(&conn, root, detail);
                    } else {
                        let _ = conn.xtest_fake_input(
                            xproto::BUTTON_RELEASE_EVENT,
                            detail,
                            0,
                            root,
                            clamp_i16(ev.x),
                            clamp_i16(ev.y),
                            0,
                        );
                    }
                }
            }
            EVT_WHEEL => {
                if ev.y != 0 {
                    click_button(&conn, root, if ev.y > 0 { 4 } else { 5 });
                }
                if ev.x != 0 {
                    click_button(&conn, root, if ev.x > 0 { 7 } else { 6 });
                }
            }
            _ => {}
        }
        let _ = conn.flush();
    }

    pub fn inject_key(ev: crate::rustdesk_proto::KeyEvent) {
        match ev.union {
            Some(crate::rustdesk_proto::key_event::Union::ControlKey(ck)) => {
                if let Some(keycode) = control_key_to_x11_keycode(ck) {
                    if ev.press {
                        send_keycode(keycode, true);
                        send_keycode(keycode, false);
                    } else {
                        send_keycode(keycode, ev.down);
                    }
                }
            }
            Some(crate::rustdesk_proto::key_event::Union::Unicode(ch)) => {
                if let Some(c) = char::from_u32(ch) {
                    if c.is_ascii() {
                        send_ascii(c);
                    }
                }
            }
            None => {}
        }
    }

    pub fn release_stuck_input() {
        for button in [1, 2, 3] {
            if let Ok((conn, screen_num)) = x11rb::connect(None) {
                let root = conn.setup().roots[screen_num].root;
                let _ =
                    conn.xtest_fake_input(xproto::BUTTON_RELEASE_EVENT, button, 0, root, 0, 0, 0);
                let _ = conn.flush();
            }
        }
        for keycode in [37, 50, 62, 64, 108, 133, 134] {
            send_keycode(keycode, false);
        }
    }

    fn click_button<C: Connection>(conn: &C, root: u32, detail: u8) {
        let _ = conn.xtest_fake_input(xproto::BUTTON_PRESS_EVENT, detail, 0, root, 0, 0, 0);
        let _ = conn.xtest_fake_input(xproto::BUTTON_RELEASE_EVENT, detail, 0, root, 0, 0, 0);
    }

    fn mouse_button_detail(button: i32) -> Option<u8> {
        match button {
            BTN_LEFT => Some(1),
            BTN_MIDDLE => Some(2),
            BTN_RIGHT => Some(3),
            _ => None,
        }
    }

    fn send_keycode(keycode: u8, down: bool) {
        let Ok((conn, screen_num)) = x11rb::connect(None) else {
            return;
        };
        let root = conn.setup().roots[screen_num].root;
        let event = if down {
            xproto::KEY_PRESS_EVENT
        } else {
            xproto::KEY_RELEASE_EVENT
        };
        let _ = conn.xtest_fake_input(event, keycode, 0, root, 0, 0, 0);
        let _ = conn.flush();
    }

    fn send_ascii(c: char) {
        let Some((keycode, shift)) = ascii_to_x11_keycode(c) else {
            return;
        };
        if shift {
            send_keycode(50, true);
        }
        send_keycode(keycode, true);
        send_keycode(keycode, false);
        if shift {
            send_keycode(50, false);
        }
    }

    fn control_key_to_x11_keycode(ck: i32) -> Option<u8> {
        use crate::rustdesk_proto::ControlKey;
        Some(match ck {
            x if x == ControlKey::Alt as i32 => 64,
            x if x == ControlKey::Backspace as i32 => 22,
            x if x == ControlKey::CapsLock as i32 => 66,
            x if x == ControlKey::Control as i32 => 37,
            x if x == ControlKey::Delete as i32 => 119,
            x if x == ControlKey::DownArrow as i32 => 116,
            x if x == ControlKey::End as i32 => 115,
            x if x == ControlKey::Escape as i32 => 9,
            x if x == ControlKey::F1 as i32 => 67,
            x if x == ControlKey::F2 as i32 => 68,
            x if x == ControlKey::F3 as i32 => 69,
            x if x == ControlKey::F4 as i32 => 70,
            x if x == ControlKey::F5 as i32 => 71,
            x if x == ControlKey::F6 as i32 => 72,
            x if x == ControlKey::F7 as i32 => 73,
            x if x == ControlKey::F8 as i32 => 74,
            x if x == ControlKey::F9 as i32 => 75,
            x if x == ControlKey::F10 as i32 => 76,
            x if x == ControlKey::F11 as i32 => 95,
            x if x == ControlKey::F12 as i32 => 96,
            x if x == ControlKey::Home as i32 => 110,
            x if x == ControlKey::Insert as i32 => 118,
            x if x == ControlKey::LeftArrow as i32 => 113,
            x if x == ControlKey::Meta as i32 => 133,
            x if x == ControlKey::PageDown as i32 => 117,
            x if x == ControlKey::PageUp as i32 => 112,
            x if x == ControlKey::Return as i32 => 36,
            x if x == ControlKey::NumpadEnter as i32 => 104,
            x if x == ControlKey::RightArrow as i32 => 114,
            x if x == ControlKey::Shift as i32 => 50,
            x if x == ControlKey::Space as i32 => 65,
            x if x == ControlKey::Tab as i32 => 23,
            x if x == ControlKey::UpArrow as i32 => 111,
            _ => return None,
        })
    }

    fn ascii_to_x11_keycode(c: char) -> Option<(u8, bool)> {
        Some(match c {
            'a'..='z' => ((c as u8 - b'a') + 38, false),
            'A'..='Z' => ((c as u8 - b'A') + 38, true),
            '1' => (10, false),
            '2' => (11, false),
            '3' => (12, false),
            '4' => (13, false),
            '5' => (14, false),
            '6' => (15, false),
            '7' => (16, false),
            '8' => (17, false),
            '9' => (18, false),
            '0' => (19, false),
            '!' => (10, true),
            '@' => (11, true),
            '#' => (12, true),
            '$' => (13, true),
            '%' => (14, true),
            '^' => (15, true),
            '&' => (16, true),
            '*' => (17, true),
            '(' => (18, true),
            ')' => (19, true),
            '-' => (20, false),
            '_' => (20, true),
            '=' => (21, false),
            '+' => (21, true),
            '[' => (34, false),
            '{' => (34, true),
            ']' => (35, false),
            '}' => (35, true),
            ';' => (47, false),
            ':' => (47, true),
            '\'' => (48, false),
            '"' => (48, true),
            '`' => (49, false),
            '~' => (49, true),
            '\\' => (51, false),
            '|' => (51, true),
            ',' => (59, false),
            '<' => (59, true),
            '.' => (60, false),
            '>' => (60, true),
            '/' => (61, false),
            '?' => (61, true),
            ' ' => (65, false),
            _ => return None,
        })
    }

    fn clamp_i16(value: i32) -> i16 {
        value.clamp(i16::MIN as i32, i16::MAX as i32) as i16
    }
}

/// Map RustDesk ControlKey enum value to Windows VK_ code.
#[cfg(all(target_os = "windows", feature = "live-vp9-mf"))]
fn control_key_to_vk(ck: i32) -> u16 {
    use crate::rustdesk_proto::ControlKey;
    // ControlKey variants are i32 from prost; cast and match.
    match ck {
        x if x == ControlKey::Alt as i32 => 0x12,
        x if x == ControlKey::Backspace as i32 => 0x08,
        x if x == ControlKey::CapsLock as i32 => 0x14,
        x if x == ControlKey::Control as i32 => 0x11,
        x if x == ControlKey::Delete as i32 => 0x2E,
        x if x == ControlKey::End as i32 => 0x23,
        x if x == ControlKey::Escape as i32 => 0x1B,
        x if x == ControlKey::Home as i32 => 0x24,
        x if x == ControlKey::LeftArrow as i32 => 0x25,
        x if x == ControlKey::UpArrow as i32 => 0x26,
        x if x == ControlKey::RightArrow as i32 => 0x27,
        x if x == ControlKey::DownArrow as i32 => 0x28,
        x if x == ControlKey::Return as i32 => 0x0D,
        x if x == ControlKey::PageUp as i32 => 0x21,
        x if x == ControlKey::PageDown as i32 => 0x22,
        x if x == ControlKey::Shift as i32 => 0x10,
        x if x == ControlKey::Space as i32 => 0x20,
        x if x == ControlKey::Tab as i32 => 0x09,
        x if x == ControlKey::F1 as i32 => 0x70,
        x if x == ControlKey::F2 as i32 => 0x71,
        x if x == ControlKey::F3 as i32 => 0x72,
        x if x == ControlKey::F4 as i32 => 0x73,
        x if x == ControlKey::F5 as i32 => 0x74,
        x if x == ControlKey::F6 as i32 => 0x75,
        x if x == ControlKey::F7 as i32 => 0x76,
        x if x == ControlKey::F8 as i32 => 0x77,
        x if x == ControlKey::F9 as i32 => 0x78,
        x if x == ControlKey::F10 as i32 => 0x79,
        x if x == ControlKey::F11 as i32 => 0x7A,
        x if x == ControlKey::F12 as i32 => 0x7B,
        x if x == ControlKey::Meta as i32 => 0x5B, // Win key
        x if x == ControlKey::CtrlAltDel as i32 => 0x2E, // just Del; real CAD needs UAC bypass
        _ => 0,
    }
}

// ── Auth helpers ──────────────────────────────────────────────────────────────

fn verify_password(received: &[u8], our_password: &str, salt: &str, challenge: &str) -> bool {
    // Empty received hash means "remote approval" mode.
    if received.is_empty() {
        return our_password.is_empty();
    }
    // Match the algorithm used by build_login_request in transport.rs:
    // h1 = sha256(password || salt)
    // h2 = sha256(h1 || challenge)
    let mut h1 = Sha256::new();
    h1.update(our_password.as_bytes());
    h1.update(salt.as_bytes());
    let h1 = h1.finalize();

    let mut h2 = Sha256::new();
    h2.update(h1.as_slice());
    h2.update(challenge.as_bytes());
    let expected = h2.finalize();

    received == expected.as_slice()
}

// ── Utility ───────────────────────────────────────────────────────────────────

fn send_register_peer_udp(socket: &UdpSocket, server: &str, local_id: &str) -> Result<(), String> {
    let msg = RendezvousMessage {
        union: Some(rendezvous_message::Union::RegisterPeer(RegisterPeer {
            id: local_id.to_owned(),
            serial: 0,
        })),
    };
    socket
        .send_to(&encode_message(&msg), server)
        .map(|_| ())
        .map_err(|e| format!("UDP send_to: {e}"))
}

/// Sends `RegisterPk`. `sign_pk` is our stable Ed25519 public key (32 bytes);
/// if it isn't a valid 32-byte key we fall back to a deterministic fake so the
/// call still does something sensible.
fn send_register_pk_udp(
    socket: &UdpSocket,
    server: &str,
    local_id: &str,
    sign_pk: &[u8],
) -> Result<(), String> {
    use sha2::{Digest, Sha256};

    let pk: Vec<u8> = if sign_pk.len() == 32 {
        sign_pk.to_vec()
    } else {
        let mut h = Sha256::new();
        h.update(b"evertydesk-pk:");
        h.update(local_id.as_bytes());
        h.finalize().to_vec()
    };

    let mut hu = Sha256::new();
    hu.update(b"evertydesk-uuid:");
    hu.update(local_id.as_bytes());
    let uuid_bytes: Vec<u8> = hu.finalize()[..16].to_vec();

    let msg = RendezvousMessage {
        union: Some(rendezvous_message::Union::RegisterPk(RegisterPk {
            id: local_id.to_owned(),
            uuid: uuid_bytes,
            pk,
            old_pk: Vec::new(),
        })),
    };
    socket
        .send_to(&encode_message(&msg), server)
        .map(|_| ())
        .map_err(|e| format!("UDP send_to RegisterPk: {e}"))
}

#[allow(dead_code)]
fn read_peer_msg_timeout(stream: &mut TcpStream, timeout: Duration) -> Result<PeerMessage, String> {
    stream
        .set_read_timeout(Some(timeout))
        .map_err(|e| format!("set_read_timeout: {e}"))?;
    let payload = read_framed(stream)?;
    decode_peer_message(&payload).map_err(|e| format!("Peer decode: {e}"))
}

/// UDP loopback test — sends a packet from one local socket to another and
/// reads it back.  If this fails, `recv_from` is broken on this machine
/// (driver / Winsock issue).
fn udp_loopback_test(events: &Sender<HostEvent>) {
    host_log(events, "UDP loopback test…".to_owned());

    let sock_tx = match UdpSocket::bind("127.0.0.1:0") {
        Ok(s) => s,
        Err(e) => {
            host_log(events, format!("UDP loopback: bind TX: {e}"));
            return;
        }
    };
    let sock_rx = match UdpSocket::bind("127.0.0.1:0") {
        Ok(s) => s,
        Err(e) => {
            host_log(events, format!("UDP loopback: bind RX: {e}"));
            return;
        }
    };
    let addr_rx = match sock_rx.local_addr() {
        Ok(a) => a,
        Err(e) => {
            host_log(events, format!("UDP loopback: addr: {e}"));
            return;
        }
    };

    if let Err(e) = sock_tx.send_to(b"EvertyDesk-ping", addr_rx) {
        host_log(events, format!("UDP loopback: send: {e}"));
        return;
    }
    sock_rx
        .set_read_timeout(Some(Duration::from_millis(500)))
        .ok();
    let mut buf = [0u8; 32];
    match sock_rx.recv_from(&mut buf) {
        Ok((n, _)) if &buf[..n] == b"EvertyDesk-ping" => {
            host_log(events, "UDP loopback: PASS ✓ — recv_from works".to_owned())
        }
        Ok((n, src)) => host_log(
            events,
            format!("UDP loopback: unexpected data {n}B from {src}"),
        ),
        Err(e) => host_log(events, format!("UDP loopback: FAIL — recv_from: {e}")),
    }
}

/// Internet UDP test — sends a minimal DNS query to 1.1.1.1:53 and waits for
/// a response.  If the response arrives, inbound UDP from the internet works
/// (NAT + firewall OK).  If it times out, something is blocking inbound UDP.
fn udp_internet_test(events: &Sender<HostEvent>) {
    host_log(events, "UDP internet test (DNS → 1.1.1.1:53)…".to_owned());

    let sock = match UdpSocket::bind("0.0.0.0:0") {
        Ok(s) => s,
        Err(e) => {
            host_log(events, format!("UDP internet: bind: {e}"));
            return;
        }
    };

    // Minimal DNS query: A record for "a.com"
    //   ID=0x1234, flags=0x0100 (standard query RD), QDCOUNT=1
    //   QNAME=\x01a\x03com\x00  QTYPE=A(1)  QCLASS=IN(1)
    let dns_query: &[u8] = &[
        0x12, 0x34, // ID
        0x01, 0x00, // Flags: standard query, recursion desired
        0x00, 0x01, // QDCOUNT = 1
        0x00, 0x00, // ANCOUNT = 0
        0x00, 0x00, // NSCOUNT = 0
        0x00, 0x00, // ARCOUNT = 0
        0x01, b'a', // \x01 + "a"
        0x03, b'c', b'o', b'm', // \x03 + "com"
        0x00, // root label
        0x00, 0x01, // QTYPE = A
        0x00, 0x01, // QCLASS = IN
    ];

    if let Err(e) = sock.send_to(dns_query, "1.1.1.1:53") {
        host_log(events, format!("UDP internet: send: {e}"));
        return;
    }
    host_log(
        events,
        "UDP internet: DNS query sent → 1.1.1.1:53".to_owned(),
    );

    sock.set_read_timeout(Some(Duration::from_secs(3))).ok();
    let mut buf = [0u8; 512];
    match sock.recv_from(&mut buf) {
        Ok((n, src)) => host_log(
            events,
            format!(
                "UDP internet: PASS ✓ — got {n}B from {src} (inbound UDP from internet works!)"
            ),
        ),
        Err(ref e)
            if e.kind() == std::io::ErrorKind::WouldBlock
                || e.kind() == std::io::ErrorKind::TimedOut =>
        {
            host_log(
                events,
                "UDP internet: FAIL — timeout (3s, no response from 1.1.1.1:53) \
                → inbound UDP from internet is BLOCKED"
                    .to_owned(),
            )
        }
        Err(e) => host_log(events, format!("UDP internet: FAIL — recv_from: {e}")),
    }
}

/// Returns the first ≤ 20 bytes of `bytes` as space-separated uppercase hex.
/// Appends " …(N total)" if the slice is longer than 20 bytes.
fn hex_short(bytes: &[u8]) -> String {
    let preview = bytes.len().min(20);
    let hex = bytes[..preview]
        .iter()
        .map(|b| format!("{b:02X}"))
        .collect::<Vec<_>>()
        .join(" ");
    if bytes.len() > preview {
        format!("{hex} …({} total)", bytes.len())
    } else {
        hex
    }
}

/// Diagnostic TCP probe on the ID-server port.
///
/// Connects, logs any server greeting, sends a framed `RegisterPeer`, logs the
/// raw response (before and after decode attempts).  Pure side-effect
/// (logging); does not affect the UDP registration flow.
fn tcp_probe(host: &str, port: u16, local_id: &str, events: &Sender<HostEvent>) {
    use std::io::Read as _;
    use std::net::ToSocketAddrs;

    host_log(events, format!("=== TCP probe {host}:{port} ==="));

    // ── DNS ──────────────────────────────────────────────────────────────────
    let addr_str = format!("{host}:{port}");
    let sock_addr = match addr_str.to_socket_addrs().ok().and_then(|mut i| i.next()) {
        Some(a) => {
            host_log(events, format!("TCP probe: DNS → {}", a.ip()));
            a
        }
        None => {
            host_log(events, format!("TCP probe: DNS resolve failed for {host}"));
            return;
        }
    };

    // ── Connect ──────────────────────────────────────────────────────────────
    let mut stream = match TcpStream::connect_timeout(&sock_addr, Duration::from_secs(4)) {
        Ok(s) => {
            host_log(events, "TCP probe: connected ✓".to_owned());
            s
        }
        Err(e) => {
            host_log(events, format!("TCP probe: connect failed: {e}"));
            return;
        }
    };

    // ── 1. Read any server greeting ──────────────────────────────────────────
    stream
        .set_read_timeout(Some(Duration::from_millis(700)))
        .ok();
    let mut gbuf = [0u8; 256];
    match stream.read(&mut gbuf) {
        Ok(0) => host_log(
            events,
            "TCP probe: server closed immediately (EOF before send)".to_owned(),
        ),
        Ok(n) => host_log(
            events,
            format!("TCP probe: server greeting {n}B: {}", hex_short(&gbuf[..n])),
        ),
        Err(ref e)
            if e.kind() == std::io::ErrorKind::WouldBlock
                || e.kind() == std::io::ErrorKind::TimedOut =>
        {
            host_log(
                events,
                "TCP probe: no greeting (server silent after connect)".to_owned(),
            )
        }
        Err(e) => host_log(events, format!("TCP probe: greeting read err: {e}")),
    }

    // ── 2. Send framed RegisterPeer ──────────────────────────────────────────
    let payload = encode_message(&RendezvousMessage {
        union: Some(rendezvous_message::Union::RegisterPeer(RegisterPeer {
            id: local_id.to_owned(),
            serial: 0,
        })),
    });
    host_log(
        events,
        format!(
            "TCP probe: sending framed RegisterPeer {}B: {}",
            payload.len(),
            hex_short(&payload)
        ),
    );
    if let Err(e) = send_framed(&mut stream, &payload) {
        host_log(events, format!("TCP probe: send_framed err: {e}"));
        return;
    }

    // ── 3. Read server response ───────────────────────────────────────────────
    stream.set_read_timeout(Some(Duration::from_secs(2))).ok();
    let mut rbuf = [0u8; 1024];
    match stream.read(&mut rbuf) {
        Ok(0) => host_log(
            events,
            "TCP probe: server closed after our message (EOF) — normal for TCP 21116".to_owned(),
        ),
        Ok(n) => {
            host_log(
                events,
                format!("TCP probe: server replied {n}B: {}", hex_short(&rbuf[..n])),
            );
            // Try raw proto decode
            if let Ok(m) = decode_message(&rbuf[..n]) {
                host_log(
                    events,
                    format!(
                        "TCP probe: raw-decode → {}",
                        match &m.union {
                            Some(rendezvous_message::Union::RegisterPeerResponse(r)) =>
                                format!("RegisterPeerResponse request_pk={}", r.request_pk),
                            Some(_) => "other variant".to_owned(),
                            None => "empty union".to_owned(),
                        }
                    ),
                );
            }
            // Try framed decode (4-byte big-endian length prefix)
            if n > 4 {
                let declared = u32::from_be_bytes([rbuf[0], rbuf[1], rbuf[2], rbuf[3]]) as usize;
                host_log(events, format!("TCP probe: 4-byte prefix = {declared}"));
                if declared > 0 && 4 + declared <= n {
                    if let Ok(m) = decode_message(&rbuf[4..4 + declared]) {
                        host_log(
                            events,
                            format!(
                                "TCP probe: framed-decode → {}",
                                match &m.union {
                                    Some(rendezvous_message::Union::RegisterPeerResponse(r)) =>
                                        format!("RegisterPeerResponse request_pk={}", r.request_pk),
                                    Some(_) => "other variant".to_owned(),
                                    None => "empty union".to_owned(),
                                }
                            ),
                        );
                    }
                }
            }
        }
        Err(ref e)
            if e.kind() == std::io::ErrorKind::WouldBlock
                || e.kind() == std::io::ErrorKind::TimedOut =>
        {
            host_log(
                events,
                "TCP probe: no response (timeout after 2s)".to_owned(),
            )
        }
        Err(e) => host_log(events, format!("TCP probe: response read err: {e}")),
    }

    host_log(events, "=== TCP probe done ===".to_owned());
}

/// Send a PeerMessage over the relay, encrypting it if the secure channel is up.
fn send_peer_enc(
    stream: &mut TcpStream,
    cipher: &mut Option<StreamCipher>,
    msg: &PeerMessage,
) -> Result<(), String> {
    let mut bytes = encode_peer_message(msg);
    if let Some(c) = cipher.as_mut() {
        bytes = c.encrypt(&bytes);
    }
    send_framed(stream, &bytes)
}

/// Read a PeerMessage from the relay, decrypting if the secure channel is up.
/// Returns `Ok(None)` for empty keepalive frames.
fn recv_peer_enc(
    stream: &mut TcpStream,
    cipher: &mut Option<StreamCipher>,
) -> Result<Option<PeerMessage>, String> {
    let payload = read_framed(stream)?;
    if payload.is_empty() {
        return Ok(None);
    }
    let plain = if let Some(c) = cipher.as_mut() {
        c.decrypt(&payload)?
    } else {
        payload
    };
    let msg = decode_peer_message(&plain).map_err(|e| format!("Peer decode: {e}"))?;
    Ok(Some(msg))
}

/// Send a `LoginResponse{ Error }` (encrypted if the secure channel is up).
/// Use RustDesk's exact strings ("Empty Password" / "Wrong Password") so the
/// peer shows its password dialog and retries on the same connection.
fn send_login_error(
    stream: &mut TcpStream,
    cipher: &mut Option<StreamCipher>,
    message: &str,
) -> Result<(), String> {
    let msg = PeerMessage {
        union: Some(peer_message::Union::LoginResponse(LoginResponse {
            union: Some(login_response::Union::Error(message.to_owned())),
        })),
    };
    send_peer_enc(stream, cipher, &msg)
}

/// Human-readable name of a peer_message variant (for diagnostics).
fn peer_msg_kind(union: &Option<peer_message::Union>) -> &'static str {
    use peer_message::Union as U;
    match union {
        Some(U::LoginRequest(_)) => "LoginRequest",
        Some(U::LoginResponse(_)) => "LoginResponse",
        Some(U::Hash(_)) => "Hash",
        Some(U::PublicKey(_)) => "PublicKey",
        Some(U::SignedId(_)) => "SignedId",
        Some(U::TestDelay(_)) => "TestDelay",
        Some(U::VideoFrame(_)) => "VideoFrame",
        Some(U::MouseEvent(_)) => "MouseEvent",
        Some(U::KeyEvent(_)) => "KeyEvent",
        Some(U::Misc(_)) => "Misc",
        Some(_) => "other",
        None => "empty",
    }
}

fn host_log(events: &Sender<HostEvent>, msg: String) {
    // Don't eprintln! here — the GUI shows logs in the log panel, and the
    // headless --host loop already prints everything it receives from the
    // channel.  Printing here would cause every line to appear twice in
    // headless mode.
    let _ = events.send(HostEvent::Log(msg));
}

fn is_timeout(e: &str) -> bool {
    e.contains("timed out") || e.contains("WouldBlock") || e.contains("os error 10060")
}

fn random_u64() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    let ns = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    let pid = std::process::id() as u128;
    // Simple deterministic mix — not crypto-quality but good enough for salt/challenge.
    let v = ns ^ (pid << 32) ^ (ns >> 17) ^ 0xDEAD_BEEF_CAFE_1234;
    v as u64
}

fn hostname() -> String {
    std::env::var("COMPUTERNAME")
        .or_else(|_| std::env::var("HOSTNAME"))
        .unwrap_or_else(|_| "EvertyDesk".to_owned())
}
