use std::{
    cell::RefCell,
    rc::Rc,
    sync::mpsc::{self, Receiver, Sender},
    thread,
    time::Instant,
};

use font8x8::UnicodeFonts;
use minifb::{InputCallback, Key, KeyRepeat, MouseButton, MouseMode, Window, WindowOptions};

use crate::{
    settings::AppConfig,
    transport::{ConnectionRequest, SessionCommand, SessionEvent, TransportClient},
    video, APP_NAME,
};

const WIDTH: usize = 980;
const HEIGHT: usize = 660;
const BG: u32 = 0x14181c;
const PANEL: u32 = 0x20262c;
const PANEL_2: u32 = 0x2b333a;
const TEXT: u32 = 0xe6edf3;
const MUTED: u32 = 0x8b98a5;
const ACCENT: u32 = 0x2f9e8f;
const BUTTON: u32 = 0x315f7c;

type Chars = Rc<RefCell<Vec<u32>>>;

struct CharInput {
    chars: Chars,
}

impl InputCallback for CharInput {
    fn add_char(&mut self, uni_char: u32) {
        self.chars.borrow_mut().push(uni_char);
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum Field {
    RemoteId,
    Password,
}

#[derive(Clone, Copy)]
struct Rect {
    x: usize,
    y: usize,
    w: usize,
    h: usize,
}

impl Rect {
    fn contains(self, x: f32, y: f32) -> bool {
        x >= self.x as f32
            && y >= self.y as f32
            && x < (self.x + self.w) as f32
            && y < (self.y + self.h) as f32
    }
}

pub fn run_software_ui() -> Result<(), String> {
    let mut window = Window::new(
        APP_NAME,
        WIDTH,
        HEIGHT,
        WindowOptions {
            resize: true,
            ..WindowOptions::default()
        },
    )
    .map_err(|err| format!("open CPU window failed: {err}"))?;
    window.set_target_fps(60);
    eprintln!(
        "[EvertyDesk] CPU software UI opened. Build codecs: {}",
        video::build_codec_label()
    );

    let chars = Chars::new(RefCell::new(Vec::new()));
    window.set_input_callback(Box::new(CharInput {
        chars: chars.clone(),
    }));

    let config = AppConfig::load_or_create();
    let mut app = SoftApp::new(config);
    let mut buffer = vec![0_u32; WIDTH * HEIGHT];
    let mut last_left = false;
    let mut last_right = false;
    let mut last_middle = false;

    while window.is_open() && !window.is_key_down(Key::Escape) {
        let (w, h) = window.get_size();
        if buffer.len() != w * h {
            buffer.resize(w * h, BG);
        }

        for key in window.get_keys_pressed(KeyRepeat::Yes) {
            app.handle_key(key);
        }
        {
            let mut typed = chars.borrow_mut();
            for ch in typed.drain(..) {
                if let Some(ch) = char::from_u32(ch) {
                    app.handle_char(ch);
                }
            }
        }

        let mouse = window.get_mouse_pos(MouseMode::Discard);
        let left = window.get_mouse_down(MouseButton::Left);
        let right = window.get_mouse_down(MouseButton::Right);
        let middle = window.get_mouse_down(MouseButton::Middle);
        if let Some((mx, my)) = mouse {
            app.handle_mouse(
                mx,
                my,
                left,
                last_left,
                right,
                last_right,
                middle,
                last_middle,
            );
        }
        if let Some((sx, sy)) = window.get_scroll_wheel() {
            app.handle_scroll(sx, sy);
        }
        last_left = left;
        last_right = right;
        last_middle = middle;

        app.poll_events();
        app.draw(&mut buffer, w, h);
        window
            .update_with_buffer(&buffer, w, h)
            .map_err(|err| format!("software window update failed: {err}"))?;
    }

    app.disconnect();
    eprintln!("[EvertyDesk] CPU software UI closed.");
    Ok(())
}

struct SoftApp {
    config: AppConfig,
    remote_id: String,
    password: String,
    show_password: bool,
    focus: Field,
    status: String,
    log: Vec<String>,
    session_tx: Option<Sender<SessionCommand>>,
    event_rx: Option<Receiver<SessionEvent>>,
    connected: bool,
    busy: bool,
    progress: u8,
    frame: Vec<u8>,
    frame_size: (usize, usize),
    last_codec: String,
    last_frame_at: Option<Instant>,
    screen_rect: Option<Rect>,
    last_remote_pos: Option<(i32, i32)>,
}

impl SoftApp {
    fn new(config: AppConfig) -> Self {
        Self {
            remote_id: config.ui.last_remote_id.clone(),
            config,
            password: String::new(),
            show_password: false,
            focus: Field::RemoteId,
            status: "Software UI ready".to_owned(),
            log: vec![
                "CPU window opened without OpenGL/Vulkan".to_owned(),
                "Type ID, Tab to password, Enter to connect".to_owned(),
            ],
            session_tx: None,
            event_rx: None,
            connected: false,
            busy: false,
            progress: 0,
            frame: Vec::new(),
            frame_size: (0, 0),
            last_codec: "none".to_owned(),
            last_frame_at: None,
            screen_rect: None,
            last_remote_pos: None,
        }
    }

    fn handle_char(&mut self, ch: char) {
        if ch.is_control() {
            return;
        }
        match self.focus {
            Field::RemoteId => {
                if ch.is_ascii_digit() || ch == ' ' || ch == '-' {
                    self.remote_id.push(ch);
                }
            }
            Field::Password => self.password.push(ch),
        }
    }

    fn handle_key(&mut self, key: Key) {
        match key {
            Key::Backspace => match self.focus {
                Field::RemoteId => {
                    self.remote_id.pop();
                }
                Field::Password => {
                    self.password.pop();
                }
            },
            Key::Tab => self.focus = next_field(self.focus),
            Key::Enter => {
                if self.connected {
                    self.disconnect();
                } else if !self.busy {
                    self.connect();
                }
            }
            Key::F5 => self.send(SessionCommand::Screenshot),
            _ => {
                if self.connected {
                    if let Some(command) = key_to_command(key) {
                        self.send(command);
                    }
                }
            }
        }
    }

    fn handle_mouse(
        &mut self,
        mx: f32,
        my: f32,
        left: bool,
        last_left: bool,
        right: bool,
        last_right: bool,
        middle: bool,
        last_middle: bool,
    ) {
        let id_rect = Rect {
            x: 24,
            y: 88,
            w: 250,
            h: 34,
        };
        let pass_rect = Rect {
            x: 288,
            y: 88,
            w: 250,
            h: 34,
        };
        let show_rect = Rect {
            x: 552,
            y: 88,
            w: 88,
            h: 34,
        };
        let connect_rect = Rect {
            x: 654,
            y: 88,
            w: 140,
            h: 34,
        };
        let disconnect_rect = Rect {
            x: 808,
            y: 88,
            w: 140,
            h: 34,
        };

        if left && !last_left {
            if id_rect.contains(mx, my) {
                self.focus = Field::RemoteId;
            } else if pass_rect.contains(mx, my) {
                self.focus = Field::Password;
            } else if show_rect.contains(mx, my) {
                self.show_password = !self.show_password;
            } else if connect_rect.contains(mx, my) && !self.busy {
                self.connect();
            } else if disconnect_rect.contains(mx, my) {
                self.disconnect();
            }
        }

        if let Some((x, y)) = self.remote_xy(mx, my) {
            if self.last_remote_pos != Some((x, y)) {
                self.send(SessionCommand::MouseMove { x, y });
                self.last_remote_pos = Some((x, y));
            }
            if left && !last_left {
                self.send(SessionCommand::MouseDown { x, y });
            } else if !left && last_left {
                self.send(SessionCommand::MouseUp { x, y });
            }
            if right && !last_right {
                self.send(SessionCommand::MouseRightDown { x, y });
            } else if !right && last_right {
                self.send(SessionCommand::MouseRightUp { x, y });
            }
            if middle && !last_middle {
                self.send(SessionCommand::MouseMiddleDown { x, y });
            } else if !middle && last_middle {
                self.send(SessionCommand::MouseMiddleUp { x, y });
            }
        }
    }

    fn handle_scroll(&mut self, sx: f32, sy: f32) {
        if sx == 0.0 && sy == 0.0 {
            return;
        }
        if self.last_remote_pos.is_some() {
            self.send(SessionCommand::MouseWheel {
                x: sx.round() as i32,
                y: sy.round() as i32,
            });
        }
    }

    fn connect(&mut self) {
        let remote_id = normalize_remote_id(&self.remote_id);
        if remote_id.is_empty() {
            self.status = "Enter remote ID".to_owned();
            return;
        }
        self.remote_id = remote_id.clone();
        let request = ConnectionRequest {
            remote_id: remote_id.clone(),
            password: self.password.clone(),
            server: self.config.server.clone(),
        };
        let (cmd_tx, cmd_rx) = mpsc::channel();
        let (event_tx, event_rx) = mpsc::channel();
        thread::spawn(move || TransportClient::run_session(request, cmd_rx, event_tx));
        self.session_tx = Some(cmd_tx);
        self.event_rx = Some(event_rx);
        self.connected = false;
        self.busy = true;
        self.progress = 5;
        self.frame.clear();
        self.frame_size = (0, 0);
        self.status = format!("Connecting to {remote_id}");
        self.push_log(format!("Connecting to {remote_id}"));
    }

    fn disconnect(&mut self) {
        if let Some(tx) = self.session_tx.take() {
            let _ = tx.send(SessionCommand::Close);
        }
        self.event_rx = None;
        self.connected = false;
        self.busy = false;
        self.progress = 0;
        self.status = "Disconnected".to_owned();
    }

    fn poll_events(&mut self) {
        let mut events = Vec::new();
        if let Some(rx) = &self.event_rx {
            while let Ok(event) = rx.try_recv() {
                events.push(event);
            }
        }
        for event in events {
            match event {
                SessionEvent::Progress(pct, msg) => {
                    self.progress = pct;
                    self.status = msg.clone();
                    self.push_log(format!("{pct}% - {msg}"));
                }
                SessionEvent::Connected(stage) => {
                    self.connected = true;
                    self.busy = false;
                    self.progress = 100;
                    self.status = "Connected".to_owned();
                    self.push_log(format!("Connected: {stage}"));
                    self.send(SessionCommand::SetAutoRefresh {
                        enabled: true,
                        millis: 80,
                    });
                    self.send(SessionCommand::SetVideoFps { fps: 30 });
                    self.send(SessionCommand::Screenshot);
                }
                SessionEvent::Frame {
                    codec,
                    width,
                    height,
                    rgba,
                    ..
                } => {
                    self.frame = rgba;
                    self.frame_size = (width, height);
                    self.last_codec = codec;
                    self.last_frame_at = Some(Instant::now());
                }
                SessionEvent::Info(msg) => self.push_log(msg),
                SessionEvent::Failed(err) => {
                    self.status = friendly_error(&err);
                    self.push_log(format!("Error: {err}"));
                    self.busy = false;
                    self.connected = false;
                    self.session_tx = None;
                    self.event_rx = None;
                }
                SessionEvent::Closed => {
                    self.push_log("Session closed".to_owned());
                    self.disconnect();
                }
                _ => {}
            }
        }
    }

    fn draw(&mut self, buffer: &mut [u32], w: usize, h: usize) {
        buffer.fill(BG);
        rect(buffer, w, 0, 0, w, 72, 0x101418);
        text(buffer, w, 24, 20, 2, TEXT, APP_NAME);
        text(buffer, w, 270, 25, 1, MUTED, "CPU backend");
        text(
            buffer,
            w,
            390,
            25,
            1,
            MUTED,
            &format!("build codecs: {}", video::build_codec_label()),
        );

        field(
            buffer,
            w,
            Rect {
                x: 24,
                y: 88,
                w: 250,
                h: 34,
            },
            "Remote ID",
            &format_peer_id(&self.remote_id),
            self.focus == Field::RemoteId,
        );
        field(
            buffer,
            w,
            Rect {
                x: 288,
                y: 88,
                w: 250,
                h: 34,
            },
            "Password",
            if self.show_password {
                &self.password
            } else {
                "********"
            },
            self.focus == Field::Password,
        );
        button(
            buffer,
            w,
            Rect {
                x: 552,
                y: 88,
                w: 88,
                h: 34,
            },
            if self.show_password { "Hide" } else { "Show" },
        );
        button(
            buffer,
            w,
            Rect {
                x: 654,
                y: 88,
                w: 140,
                h: 34,
            },
            if self.busy { "Connecting" } else { "Connect" },
        );
        button(
            buffer,
            w,
            Rect {
                x: 808,
                y: 88,
                w: 140,
                h: 34,
            },
            "Disconnect",
        );

        let status_color = if self.connected { ACCENT } else { TEXT };
        text(buffer, w, 24, 138, 1, status_color, &self.status);
        progress(buffer, w, 24, 160, w.saturating_sub(48), 6, self.progress);

        let screen = Rect {
            x: 24,
            y: 184,
            w: w.saturating_sub(48).max(120),
            h: h.saturating_sub(260).max(160),
        };
        rect(buffer, w, screen.x, screen.y, screen.w, screen.h, 0x090b0d);
        border(buffer, w, screen, PANEL_2);
        self.screen_rect = Some(screen);
        if self.frame_size.0 > 0 && self.frame_size.1 > 0 {
            draw_frame(buffer, w, screen, &self.frame, self.frame_size);
        } else {
            text(
                buffer,
                w,
                screen.x + 20,
                screen.y + 24,
                1,
                MUTED,
                "Waiting for remote video",
            );
        }

        let bottom_y = screen.y + screen.h + 14;
        rect(
            buffer,
            w,
            24,
            bottom_y,
            w.saturating_sub(48),
            h.saturating_sub(bottom_y + 20),
            PANEL,
        );
        text(
            buffer,
            w,
            38,
            bottom_y + 14,
            1,
            TEXT,
            &format!("stream: {}", self.last_codec),
        );
        text(
            buffer,
            w,
            166,
            bottom_y + 14,
            1,
            MUTED,
            &format!("build: {}", video::build_codec_label()),
        );
        text(
            buffer,
            w,
            320,
            bottom_y + 14,
            1,
            MUTED,
            &format!("frame: {}x{}", self.frame_size.0, self.frame_size.1),
        );
        if let Some(age) = self.last_frame_at.map(|t| t.elapsed().as_millis()) {
            text(
                buffer,
                w,
                500,
                bottom_y + 14,
                1,
                MUTED,
                &format!("age: {age} ms"),
            );
        }

        let mut y = bottom_y + 42;
        for line in self.log.iter().rev().take(3).rev() {
            text(buffer, w, 38, y, 1, MUTED, line);
            y += 18;
        }
    }

    fn remote_xy(&self, mx: f32, my: f32) -> Option<(i32, i32)> {
        let rect = self.screen_rect?;
        if !rect.contains(mx, my) || self.frame_size.0 == 0 || self.frame_size.1 == 0 {
            return None;
        }
        let (fw, fh) = self.frame_size;
        let scale = (rect.w as f32 / fw as f32).min(rect.h as f32 / fh as f32);
        let draw_w = (fw as f32 * scale).round();
        let draw_h = (fh as f32 * scale).round();
        let ox = rect.x as f32 + (rect.w as f32 - draw_w) * 0.5;
        let oy = rect.y as f32 + (rect.h as f32 - draw_h) * 0.5;
        if mx < ox || my < oy || mx >= ox + draw_w || my >= oy + draw_h {
            return None;
        }
        let x = ((mx - ox) / scale).round().clamp(0.0, (fw - 1) as f32) as i32;
        let y = ((my - oy) / scale).round().clamp(0.0, (fh - 1) as f32) as i32;
        Some((x, y))
    }

    fn send(&self, command: SessionCommand) {
        if let Some(tx) = &self.session_tx {
            let _ = tx.send(command);
        }
    }

    fn push_log(&mut self, line: String) {
        self.log.push(line);
        if self.log.len() > 80 {
            self.log.drain(0..20);
        }
    }
}

fn next_field(field: Field) -> Field {
    match field {
        Field::RemoteId => Field::Password,
        Field::Password => Field::RemoteId,
    }
}

fn key_to_command(key: Key) -> Option<SessionCommand> {
    let control = match key {
        Key::Enter => return Some(SessionCommand::KeyEnter),
        Key::Backspace => crate::rustdesk_proto::ControlKey::Backspace,
        Key::Delete => crate::rustdesk_proto::ControlKey::Delete,
        Key::Tab => crate::rustdesk_proto::ControlKey::Tab,
        Key::Up => crate::rustdesk_proto::ControlKey::UpArrow,
        Key::Down => crate::rustdesk_proto::ControlKey::DownArrow,
        Key::Left => crate::rustdesk_proto::ControlKey::LeftArrow,
        Key::Right => crate::rustdesk_proto::ControlKey::RightArrow,
        Key::Home => crate::rustdesk_proto::ControlKey::Home,
        Key::End => crate::rustdesk_proto::ControlKey::End,
        Key::PageUp => crate::rustdesk_proto::ControlKey::PageUp,
        Key::PageDown => crate::rustdesk_proto::ControlKey::PageDown,
        _ => return None,
    };
    Some(SessionCommand::KeyControl(control))
}

fn rect(buffer: &mut [u32], stride: usize, x: usize, y: usize, w: usize, h: usize, color: u32) {
    let max_y = ((y + h).min(buffer.len() / stride)).max(y);
    let max_x = (x + w).min(stride);
    for yy in y..max_y {
        let row = yy * stride;
        for xx in x..max_x {
            buffer[row + xx] = color;
        }
    }
}

fn border(buffer: &mut [u32], stride: usize, r: Rect, color: u32) {
    rect(buffer, stride, r.x, r.y, r.w, 1, color);
    rect(
        buffer,
        stride,
        r.x,
        r.y + r.h.saturating_sub(1),
        r.w,
        1,
        color,
    );
    rect(buffer, stride, r.x, r.y, 1, r.h, color);
    rect(
        buffer,
        stride,
        r.x + r.w.saturating_sub(1),
        r.y,
        1,
        r.h,
        color,
    );
}

fn field(buffer: &mut [u32], stride: usize, r: Rect, label: &str, value: &str, focused: bool) {
    text(buffer, stride, r.x, r.y.saturating_sub(18), 1, MUTED, label);
    rect(buffer, stride, r.x, r.y, r.w, r.h, PANEL);
    border(buffer, stride, r, if focused { ACCENT } else { PANEL_2 });
    text(buffer, stride, r.x + 10, r.y + 10, 1, TEXT, value);
}

fn button(buffer: &mut [u32], stride: usize, r: Rect, label: &str) {
    rect(buffer, stride, r.x, r.y, r.w, r.h, BUTTON);
    border(buffer, stride, r, 0x4a87a8);
    text(buffer, stride, r.x + 12, r.y + 10, 1, TEXT, label);
}

fn progress(buffer: &mut [u32], stride: usize, x: usize, y: usize, w: usize, h: usize, pct: u8) {
    rect(buffer, stride, x, y, w, h, PANEL_2);
    rect(
        buffer,
        stride,
        x,
        y,
        w.saturating_mul(pct as usize) / 100,
        h,
        ACCENT,
    );
}

fn text(buffer: &mut [u32], stride: usize, x: usize, y: usize, scale: usize, color: u32, s: &str) {
    let mut cx = x;
    for ch in s.chars().take(80) {
        let glyph = font8x8::BASIC_FONTS
            .get(ch)
            .or_else(|| font8x8::BASIC_FONTS.get('?'));
        if let Some(glyph) = glyph {
            for (gy, row) in glyph.iter().enumerate() {
                for gx in 0..8 {
                    if (row >> gx) & 1 == 1 {
                        rect(
                            buffer,
                            stride,
                            cx + gx * scale,
                            y + gy * scale,
                            scale,
                            scale,
                            color,
                        );
                    }
                }
            }
        }
        cx += 8 * scale + scale;
        if cx + 8 * scale >= stride {
            break;
        }
    }
}

fn draw_frame(buffer: &mut [u32], stride: usize, r: Rect, rgba: &[u8], size: (usize, usize)) {
    let (fw, fh) = size;
    let expected = fw.saturating_mul(fh).saturating_mul(4);
    if rgba.len() < expected || fw == 0 || fh == 0 {
        return;
    }
    let scale = (r.w as f32 / fw as f32).min(r.h as f32 / fh as f32);
    let dw = (fw as f32 * scale).round().max(1.0) as usize;
    let dh = (fh as f32 * scale).round().max(1.0) as usize;
    let ox = r.x + (r.w.saturating_sub(dw)) / 2;
    let oy = r.y + (r.h.saturating_sub(dh)) / 2;
    for y in 0..dh {
        let sy = ((y as f32 / scale) as usize).min(fh - 1);
        let dst_y = oy + y;
        if dst_y >= buffer.len() / stride {
            break;
        }
        for x in 0..dw {
            let sx = ((x as f32 / scale) as usize).min(fw - 1);
            let src = (sy * fw + sx) * 4;
            let dst_x = ox + x;
            if dst_x >= stride {
                break;
            }
            buffer[dst_y * stride + dst_x] =
                ((rgba[src] as u32) << 16) | ((rgba[src + 1] as u32) << 8) | rgba[src + 2] as u32;
        }
    }
}

fn normalize_remote_id(id: &str) -> String {
    id.chars()
        .filter(|ch| !ch.is_whitespace() && *ch != '-' && *ch != '_')
        .collect()
}

fn format_peer_id(id: &str) -> String {
    let digits: String = id.chars().filter(|c| c.is_ascii_digit()).collect();
    if digits.len() == 9 {
        format!("{} {} {}", &digits[0..3], &digits[3..6], &digits[6..9])
    } else {
        id.to_owned()
    }
}

fn friendly_error(error: &str) -> String {
    if error.contains("Wrong Password") {
        "Wrong password".to_owned()
    } else if error.contains("Offline") {
        "Remote ID is offline".to_owned()
    } else {
        error.to_owned()
    }
}
